"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, ShieldCheck, ArrowRight, Landmark, GraduationCap, Factory, Users } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Emblem from "@/components/Emblem";
import type { Role } from "@/lib/types";

const roles: { id: Role; label: string; icon: typeof Users; href: string }[] = [
  { id: "citizen", label: "Citizen", icon: Users, href: "/reports" },
  { id: "government", label: "Government", icon: Landmark, href: "/dashboard/gov" },
  { id: "university", label: "University / HEI", icon: GraduationCap, href: "/dashboard/hei" },
  { id: "industry", label: "Industry / CSR", icon: Factory, href: "/dashboard/industry" },
];

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState<Role>("citizen");
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [sentOtp, setSentOtp] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  async function sendOtp() {
    if (phone.replace(/\D/g, "").length < 10) {
      setError("Enter a valid 10-digit mobile number.");
      return;
    }
    setError("");
    setLoading(true);
    const res = await fetch("/api/otp", { method: "POST", body: JSON.stringify({ phone }) });
    const data = await res.json();
    setSentOtp(data.otp); // demo only — in production the OTP is never returned to the client
    setLoading(false);
    setStep("otp");
  }

  async function verifyOtp() {
    const code = otp.join("");
    if (code.length !== 4) {
      setError("Enter the 4-digit OTP.");
      return;
    }
    setLoading(true);
    const res = await fetch("/api/otp", {
      method: "PUT",
      body: JSON.stringify({ phone, otp: code, expected: sentOtp }),
    });
    const data = await res.json();
    setLoading(false);
    if (data.success) {
      const target = roles.find((r) => r.id === role)?.href || "/reports";
      router.push(target);
    } else {
      setError("Incorrect OTP. Please try again.");
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-6 py-16 chakra-bg">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
        <div className="flex flex-col items-center mb-6">
          <Emblem size={56} />
          <h1 className="font-display text-2xl text-navy-950 mt-3">Welcome to SAHYOG</h1>
          <p className="text-sm text-navy-500">Sign in to report, track, and collaborate</p>
        </div>

        <GlassCard>
          <div className="grid grid-cols-4 gap-1.5 mb-6 bg-navy-50 rounded-xl p-1.5">
            {roles.map((r) => (
              <button
                key={r.id}
                onClick={() => {
                  setRole(r.id);
                  setStep("phone");
                  setError("");
                }}
                className={`flex flex-col items-center gap-1 rounded-lg py-2 text-[10px] font-medium transition-colors ${
                  role === r.id ? "bg-navy-900 text-white shadow-glass-sm" : "text-navy-600 hover:bg-white"
                }`}
              >
                <r.icon size={16} />
                {r.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {step === "phone" ? (
              <motion.div key="phone" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
                <label className="text-sm font-medium text-navy-800">Mobile Number</label>
                <div className="mt-2 flex items-center gap-2 rounded-xl border border-navy-200 bg-white px-3 py-3 focus-within:ring-2 focus-within:ring-navy-300">
                  <Phone size={18} className="text-navy-400" />
                  <span className="text-navy-500 text-sm">+91</span>
                  <input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    placeholder="98765 43210"
                    className="flex-1 outline-none text-navy-900 bg-transparent"
                  />
                </div>
                {error && <p className="text-red-600 text-xs mt-2">{error}</p>}
                <button
                  onClick={sendOtp}
                  disabled={loading}
                  className="mt-5 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-navy-900 text-white py-3 font-semibold hover:bg-navy-800 transition-colors disabled:opacity-60"
                >
                  {loading ? "Sending OTP..." : "Send OTP"} <ArrowRight size={16} />
                </button>
                <p className="text-xs text-navy-400 mt-4 text-center">
                  By continuing you agree to SAHYOG&apos;s Terms of Use and Privacy Policy of the Government of Jharkhand.
                </p>
              </motion.div>
            ) : (
              <motion.div key="otp" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
                <div className="flex items-center gap-2 text-sm text-navy-700 mb-4">
                  <ShieldCheck size={16} className="text-forest-600" />
                  OTP sent to +91 {phone}
                  {sentOtp && <span className="ml-auto text-[11px] text-navy-400">(demo OTP: {sentOtp})</span>}
                </div>
                <div className="flex gap-3 justify-center">
                  {otp.map((digit, i) => (
                    <input
                      key={i}
                      ref={(el) => { inputsRef.current[i] = el; }}
                      value={digit}
                      maxLength={1}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, "");
                        const next = [...otp];
                        next[i] = val;
                        setOtp(next);
                        if (val && i < 3) inputsRef.current[i + 1]?.focus();
                      }}
                      className="h-14 w-12 text-center text-xl font-semibold rounded-xl border border-navy-200 focus:ring-2 focus:ring-navy-400 outline-none"
                    />
                  ))}
                </div>
                {error && <p className="text-red-600 text-xs mt-3 text-center">{error}</p>}
                <button
                  onClick={verifyOtp}
                  disabled={loading}
                  className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-forest-600 text-white py-3 font-semibold hover:bg-forest-700 transition-colors disabled:opacity-60"
                >
                  {loading ? "Verifying..." : "Verify & Continue"} <ArrowRight size={16} />
                </button>
                <button onClick={() => setStep("phone")} className="mt-3 w-full text-center text-sm text-navy-500 hover:text-navy-800">
                  Change number
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </GlassCard>
      </motion.div>
    </div>
  );
}
