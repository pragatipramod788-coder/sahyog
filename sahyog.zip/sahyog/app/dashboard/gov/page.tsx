"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  FileText, ShieldAlert, IndianRupee, GraduationCap, Download, CheckCircle2,
  XCircle, Sparkles, MapPin, Clock, ChevronRight,
} from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import { districts } from "@/lib/mockData";
import type { Report, Grievance, Project } from "@/lib/types";

const pendingApprovals = [
  { id: "u1", name: "Dr. Neha Kujur", org: "St. Xavier's College, Ranchi", role: "University" },
  { id: "u2", name: "Rohan Singh", org: "Usha Martin Ltd.", role: "Industry" },
];

export default function GovDashboard() {
  const [reports, setReports] = useState<Report[]>([]);
  const [grievances, setGrievances] = useState<Grievance[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tab, setTab] = useState<"queue" | "escalations" | "approvals">("queue");

  useEffect(() => {
    fetch("/api/reports").then((r) => r.json()).then((d) => setReports(d.reports));
    fetch("/api/projects").then((r) => r.json()).then((d) => setProjects(d.projects));
  }, []);

  useEffect(() => {
    // grievances derive from escalated reports (mirrors backend store)
    setGrievances(
      reports
        .filter((r) => r.grievanceId)
        .map((r) => ({
          id: r.grievanceId!,
          reportId: r.id,
          raisedAt: r.updatedAt,
          reason: "SLA breach",
          assignedOfficer: `District Nodal Officer, ${r.location.district}`,
          district: r.location.district,
          responseDeadline: r.updatedAt,
          status: "Open" as const,
        }))
    );
  }, [reports]);

  const kpis = [
    { label: "Total Reports", value: reports.length || 8, icon: FileText, tint: "text-navy-700 bg-navy-50" },
    { label: "AI-Matched", value: reports.filter((r) => r.matchedHEI).length || 6, icon: Sparkles, tint: "text-forest-700 bg-forest-50" },
    { label: "Open Escalations", value: grievances.length, icon: ShieldAlert, tint: "text-red-700 bg-red-50" },
    { label: "Funds Tracked", value: "₹4.7 Cr", icon: IndianRupee, tint: "text-saffron-700 bg-saffron-50" },
  ];

  const districtLoad = districts.map((d) => ({
    name: d,
    count: reports.filter((r) => r.location.district === d).length + Math.floor(Math.random() * 6),
  }));
  const maxLoad = Math.max(...districtLoad.map((d) => d.count), 1);

  return (
    <div className="mx-auto max-w-7xl px-6 py-14">
      <Reveal>
        <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-saffron-600 mb-1">Government of Jharkhand</p>
            <h1 className="font-display text-3xl text-navy-950">District Oversight Dashboard</h1>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 rounded-xl border border-navy-200 bg-white px-4 py-2.5 text-sm font-medium text-navy-700 hover:bg-navy-50">
              <Download size={15} /> Export PDF
            </button>
            <button className="flex items-center gap-2 rounded-xl border border-navy-200 bg-white px-4 py-2.5 text-sm font-medium text-navy-700 hover:bg-navy-50">
              <Download size={15} /> Export Excel
            </button>
          </div>
        </div>
      </Reveal>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {kpis.map((k, i) => (
          <Reveal key={k.label} delay={i * 0.05}>
            <GlassCard className="flex items-center gap-4">
              <div className={`h-11 w-11 rounded-xl flex items-center justify-center shrink-0 ${k.tint}`}>
                <k.icon size={20} />
              </div>
              <div>
                <p className="text-2xl font-bold text-navy-900">{k.value}</p>
                <p className="text-xs text-navy-500">{k.label}</p>
              </div>
            </GlassCard>
          </Reveal>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* district heatmap */}
        <Reveal className="lg:col-span-1">
          <GlassCard className="h-full">
            <p className="font-semibold text-navy-900 mb-4">District Load Heatmap</p>
            <div className="space-y-2.5">
              {districtLoad.map((d) => (
                <div key={d.name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-navy-700">{d.name}</span>
                    <span className="text-navy-400">{d.count}</span>
                  </div>
                  <div className="h-2 rounded-full bg-navy-50 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(d.count / maxLoad) * 100}%` }}
                      transition={{ duration: 0.6 }}
                      className={`h-full rounded-full ${d.count / maxLoad > 0.7 ? "bg-red-500" : d.count / maxLoad > 0.4 ? "bg-saffron-500" : "bg-forest-500"}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </Reveal>

        {/* main panel */}
        <Reveal delay={0.1} className="lg:col-span-2">
          <GlassCard className="h-full">
            <div className="flex gap-1.5 bg-navy-50 rounded-xl p-1.5 mb-5 w-fit">
              {[
                { id: "queue", label: "Problem Queue" },
                { id: "escalations", label: `Escalation Queue (${grievances.length})` },
                { id: "approvals", label: "User Approvals" },
              ].map((tabItem) => (
                <button
                  key={tabItem.id}
                  onClick={() => setTab(tabItem.id as typeof tab)}
                  className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors ${
                    tab === tabItem.id ? "bg-navy-900 text-white" : "text-navy-600 hover:bg-white"
                  }`}
                >
                  {tabItem.label}
                </button>
              ))}
            </div>

            {tab === "queue" && (
              <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
                {reports.map((r) => (
                  <div key={r.id} className="flex items-center gap-3 rounded-xl border border-navy-100 p-3.5">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-navy-900 truncate">{r.title}</p>
                      <div className="flex items-center gap-3 text-xs text-navy-500 mt-1 flex-wrap">
                        <span className="flex items-center gap-1"><MapPin size={11} /> {r.location.district}</span>
                        <span>{r.status}</span>
                        {r.matchedHEI && (
                          <span className="flex items-center gap-1 text-forest-700">
                            <GraduationCap size={11} /> {r.matchedHEI} ({Math.round((r.matchConfidence || 0) * 100)}%)
                          </span>
                        )}
                      </div>
                    </div>
                    <button className="text-xs font-medium text-navy-600 border border-navy-200 rounded-lg px-3 py-1.5 hover:bg-navy-50 shrink-0">
                      Override Match
                    </button>
                  </div>
                ))}
              </div>
            )}

            {tab === "escalations" && (
              <div className="space-y-3">
                {grievances.length === 0 ? (
                  <p className="text-sm text-navy-400 py-8 text-center">No open escalations. All reports within SLA.</p>
                ) : (
                  grievances.map((g) => (
                    <div key={g.id} className="rounded-xl border border-red-200 bg-red-50/60 p-4">
                      <div className="flex items-center justify-between mb-1.5">
                        <p className="text-sm font-semibold text-red-800">{g.id}</p>
                        <span className="text-[10px] font-semibold bg-red-600 text-white rounded-full px-2 py-0.5">MANDATORY RESPONSE</span>
                      </div>
                      <p className="text-xs text-red-700 mb-2">Report {g.reportId} · {g.district}</p>
                      <p className="text-xs text-navy-600 flex items-center gap-1"><Clock size={11} /> Assigned to {g.assignedOfficer}</p>
                    </div>
                  ))
                )}
              </div>
            )}

            {tab === "approvals" && (
              <div className="space-y-3">
                {pendingApprovals.map((u) => (
                  <div key={u.id} className="flex items-center justify-between rounded-xl border border-navy-100 p-4">
                    <div>
                      <p className="text-sm font-semibold text-navy-900">{u.name}</p>
                      <p className="text-xs text-navy-500">{u.org} · {u.role} account</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="flex items-center gap-1 rounded-lg bg-forest-600 text-white px-3 py-1.5 text-xs font-medium hover:bg-forest-700">
                        <CheckCircle2 size={13} /> Approve
                      </button>
                      <button className="flex items-center gap-1 rounded-lg border border-navy-200 text-navy-600 px-3 py-1.5 text-xs font-medium hover:bg-navy-50">
                        <XCircle size={13} /> Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
        </Reveal>
      </div>

      <Reveal delay={0.15}>
        <GlassCard className="mt-6">
          <p className="font-semibold text-navy-900 mb-4">CSR &amp; Funding Tracker</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-navy-400 border-b border-navy-100">
                  <th className="pb-2 font-medium">Project</th>
                  <th className="pb-2 font-medium">HEI</th>
                  <th className="pb-2 font-medium">Industry Partner</th>
                  <th className="pb-2 font-medium">Committed</th>
                  <th className="pb-2 font-medium">Disbursed</th>
                  <th className="pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.id} className="border-b border-navy-50 last:border-0">
                    <td className="py-3 pr-4 text-navy-900 font-medium">{p.title.slice(0, 40)}</td>
                    <td className="py-3 pr-4 text-navy-600">{p.heiName}</td>
                    <td className="py-3 pr-4 text-navy-600">{p.industryPartner || "—"}</td>
                    <td className="py-3 pr-4 text-navy-900">₹{p.fundingCommitted.toLocaleString("en-IN")}</td>
                    <td className="py-3 pr-4 text-forest-700">₹{p.fundingDisbursed.toLocaleString("en-IN")}</td>
                    <td className="py-3 pr-4">
                      <span className="text-xs font-medium bg-navy-50 text-navy-700 rounded-full px-2.5 py-1">{p.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </Reveal>
    </div>
  );
}
