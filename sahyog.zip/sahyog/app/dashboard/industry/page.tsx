"use client";

import { useEffect, useState } from "react";
import {
  Factory, IndianRupee, FileBarChart2, Handshake, MapPin, Download, Link as LinkIcon,
} from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import type { Report, Project, LedgerEntry } from "@/lib/types";

export default function IndustryDashboard() {
  const [reports, setReports] = useState<Report[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [tab, setTab] = useState<"opportunities" | "commitments" | "compliance">("opportunities");

  useEffect(() => {
    fetch("/api/reports").then((r) => r.json()).then((d) => setReports(d.reports));
    fetch("/api/projects").then((r) => r.json()).then((d) => {
      setProjects(d.projects);
      setLedger(d.ledger);
    });
  }, []);

  const myProjects = projects.filter((p) => p.industryPartner === "Tata Steel Foundation");
  const myLedger = ledger.filter((l) => l.from === "Tata Steel Foundation");
  const totalCommitted = myProjects.reduce((s, p) => s + p.fundingCommitted, 0);
  const totalDisbursed = myProjects.reduce((s, p) => s + p.fundingDisbursed, 0);

  const opportunities = reports.filter((r) => r.matchedHEI && !myProjects.find((p) => p.reportId === r.id));

  return (
    <div className="mx-auto max-w-7xl px-6 py-14">
      <Reveal>
        <div className="flex items-center gap-3 mb-8">
          <div className="h-12 w-12 rounded-xl bg-navy-900 text-white flex items-center justify-center">
            <Factory size={22} />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-navy-500">Tata Steel Foundation · CSR Desk</p>
            <h1 className="font-display text-3xl text-navy-950">Industry &amp; CSR Portal</h1>
          </div>
        </div>
      </Reveal>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <Reveal>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-navy-50 text-navy-700 flex items-center justify-center"><IndianRupee size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">₹{totalCommitted.toLocaleString("en-IN")}</p><p className="text-xs text-navy-500">Total Committed</p></div>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.05}>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-forest-50 text-forest-700 flex items-center justify-center"><Handshake size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">₹{totalDisbursed.toLocaleString("en-IN")}</p><p className="text-xs text-navy-500">Disbursed to Date</p></div>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.1}>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-saffron-50 text-saffron-700 flex items-center justify-center"><FileBarChart2 size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">{myProjects.length}</p><p className="text-xs text-navy-500">Funded Projects</p></div>
          </GlassCard>
        </Reveal>
      </div>

      <Reveal>
        <div className="flex gap-1.5 bg-navy-50 rounded-xl p-1.5 mb-5 w-fit">
          {[
            { id: "opportunities", label: "Opportunity Feed" },
            { id: "commitments", label: "My Commitments" },
            { id: "compliance", label: "CSR Compliance & Ledger" },
          ].map((tabItem) => (
            <button
              key={tabItem.id}
              onClick={() => setTab(tabItem.id as typeof tab)}
              className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                tab === tabItem.id ? "bg-navy-900 text-white" : "text-navy-600 hover:bg-white"
              }`}
            >
              {tabItem.label}
            </button>
          ))}
        </div>
      </Reveal>

      {tab === "opportunities" && (
        <div className="grid lg:grid-cols-2 gap-5">
          {opportunities.map((r, i) => (
            <Reveal key={r.id} delay={i * 0.05}>
              <GlassCard className="h-full flex flex-col">
                <span className="text-[10px] font-semibold uppercase text-navy-500 bg-navy-50 rounded-full px-2.5 py-1 w-fit mb-2">{r.category}</span>
                <p className="font-semibold text-navy-900 mb-1">{r.title}</p>
                <p className="text-xs text-navy-500 flex items-center gap-1 mb-3"><MapPin size={11} /> {r.location.district}</p>
                <p className="text-sm text-navy-600 mb-4 flex-1">
                  Matched to {r.matchedHEI} ({r.matchedDept}). Estimated funding need: ₹{(50000 + i * 15000).toLocaleString("en-IN")}.
                </p>
                <button className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-forest-600 text-white py-2.5 text-sm font-semibold hover:bg-forest-700">
                  <Handshake size={14} /> Commit Funding / Mentorship
                </button>
              </GlassCard>
            </Reveal>
          ))}
          {opportunities.length === 0 && <p className="text-sm text-navy-400 py-8 text-center col-span-2">No new opportunities right now — check back soon.</p>}
        </div>
      )}

      {tab === "commitments" && (
        <div className="space-y-4">
          {myProjects.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.05}>
              <GlassCard>
                <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                  <p className="font-semibold text-navy-900">{p.title}</p>
                  <span className="text-xs font-medium bg-navy-50 text-navy-700 rounded-full px-2.5 py-1">{p.status}</span>
                </div>
                <div className="w-full h-2 rounded-full bg-navy-50 overflow-hidden mb-2">
                  <div className="h-full bg-forest-500" style={{ width: `${Math.round((p.fundingDisbursed / p.fundingCommitted) * 100)}%` }} />
                </div>
                <p className="text-xs text-navy-500">₹{p.fundingDisbursed.toLocaleString("en-IN")} disbursed of ₹{p.fundingCommitted.toLocaleString("en-IN")} committed · {p.heiName}</p>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      )}

      {tab === "compliance" && (
        <div className="space-y-6">
          <Reveal>
            <GlassCard className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <p className="font-semibold text-navy-900">Auto-generated CSR Compliance Report</p>
                <p className="text-xs text-navy-500">Section 135, Companies Act — FY 2025-26</p>
              </div>
              <button className="flex items-center gap-2 rounded-xl bg-navy-900 text-white px-4 py-2.5 text-sm font-semibold hover:bg-navy-800">
                <Download size={15} /> Download Report
              </button>
            </GlassCard>
          </Reveal>
          <Reveal delay={0.05}>
            <GlassCard>
              <p className="font-semibold text-navy-900 mb-4 flex items-center gap-2"><LinkIcon size={16} /> Public Transparency Ledger — Your Funding Trail</p>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-navy-400 border-b border-navy-100">
                      <th className="pb-2 font-medium">Project</th>
                      <th className="pb-2 font-medium">Amount</th>
                      <th className="pb-2 font-medium">Purpose</th>
                      <th className="pb-2 font-medium">Date</th>
                      <th className="pb-2 font-medium">Tx Hash</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myLedger.map((l) => (
                      <tr key={l.id} className="border-b border-navy-50 last:border-0">
                        <td className="py-3 pr-4 text-navy-900 font-medium">{l.projectTitle.slice(0, 36)}</td>
                        <td className="py-3 pr-4 text-forest-700">₹{l.amount.toLocaleString("en-IN")}</td>
                        <td className="py-3 pr-4 text-navy-600">{l.purpose}</td>
                        <td className="py-3 pr-4 text-navy-500">{new Date(l.date).toLocaleDateString()}</td>
                        <td className="py-3 pr-4 font-mono text-xs text-navy-400">{l.txHash}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </GlassCard>
          </Reveal>
        </div>
      )}
    </div>
  );
}
