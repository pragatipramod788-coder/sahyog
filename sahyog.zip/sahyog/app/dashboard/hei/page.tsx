"use client";

import { useEffect, useState } from "react";
import {
  GraduationCap, Sparkles, FileCheck2, FolderKanban, Award, MapPin,
  Send, History, TrendingUp,
} from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import type { Report, Project } from "@/lib/types";

export default function HEIDashboard() {
  const [reports, setReports] = useState<Report[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tab, setTab] = useState<"feed" | "projects" | "portfolio">("feed");

  useEffect(() => {
    fetch("/api/reports").then((r) => r.json()).then((d) => setReports(d.reports));
    fetch("/api/projects").then((r) => r.json()).then((d) => setProjects(d.projects));
  }, []);

  const matched = reports.filter((r) => r.matchedHEI === "BIT Mesra" || r.matchedHEI === "IIT (ISM) Dhanbad" || r.matchedHEI);
  const heiProjects = projects.filter((p) => p.heiName === "BIT Mesra" || true);
  const resolvedCount = heiProjects.filter((p) => p.status === "Completed").length;

  return (
    <div className="mx-auto max-w-7xl px-6 py-14">
      <Reveal>
        <div className="flex items-center gap-3 mb-8">
          <div className="h-12 w-12 rounded-xl bg-forest-600 text-white flex items-center justify-center">
            <GraduationCap size={22} />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-forest-600">BIT Mesra · Civil Engineering Dept.</p>
            <h1 className="font-display text-3xl text-navy-950">University Research Portal</h1>
          </div>
        </div>
      </Reveal>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <Reveal>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-navy-50 text-navy-700 flex items-center justify-center"><Sparkles size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">{matched.length}</p><p className="text-xs text-navy-500">Matched Problems</p></div>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.05}>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-saffron-50 text-saffron-700 flex items-center justify-center"><FolderKanban size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">{heiProjects.length}</p><p className="text-xs text-navy-500">Active Projects</p></div>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.1}>
          <GlassCard className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-xl bg-forest-50 text-forest-700 flex items-center justify-center"><Award size={20} /></div>
            <div><p className="text-2xl font-bold text-navy-900">{resolvedCount}</p><p className="text-xs text-navy-500">Problems Resolved</p></div>
          </GlassCard>
        </Reveal>
      </div>

      <Reveal>
        <div className="flex gap-1.5 bg-navy-50 rounded-xl p-1.5 mb-5 w-fit">
          {[
            { id: "feed", label: "Matched-Problems Feed" },
            { id: "projects", label: "Active Project Tracker" },
            { id: "portfolio", label: "Impact Portfolio" },
          ].map((tabItem) => (
            <button
              key={tabItem.id}
              onClick={() => setTab(tabItem.id as typeof tab)}
              className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                tab === tabItem.id ? "bg-navy-900 text-white" : "text-navy-600 hover:bg-white"
              }`}
            >
              {tabItem.label}
            </button>
          ))}
        </div>
      </Reveal>

      {tab === "feed" && (
        <div className="grid lg:grid-cols-2 gap-5">
          {matched.map((r, i) => (
            <Reveal key={r.id} delay={i * 0.05}>
              <GlassCard className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-semibold uppercase text-navy-500 bg-navy-50 rounded-full px-2.5 py-1">{r.category}</span>
                  <span className="text-[10px] font-semibold text-forest-700">{Math.round((r.matchConfidence || 0) * 100)}% match</span>
                </div>
                <p className="font-semibold text-navy-900 mb-1">{r.title}</p>
                <p className="text-xs text-navy-500 flex items-center gap-1 mb-3"><MapPin size={11} /> {r.location.district}</p>
                <p className="text-sm text-navy-600 flex-1 mb-4">{r.description.slice(0, 110)}...</p>
                <div className="rounded-lg bg-forest-50 border border-forest-100 p-2.5 text-xs text-forest-800 flex items-center gap-2 mb-4">
                  <History size={13} /> 2 similar past-solved cases found — reuse available
                </div>
                <button className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-navy-900 text-white py-2.5 text-sm font-semibold hover:bg-navy-800">
                  <Send size={14} /> Submit Research Proposal
                </button>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      )}

      {tab === "projects" && (
        <div className="space-y-4">
          {heiProjects.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.05}>
              <GlassCard>
                <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                  <p className="font-semibold text-navy-900">{p.title}</p>
                  <span className="text-xs font-medium bg-navy-50 text-navy-700 rounded-full px-2.5 py-1">{p.status}</span>
                </div>
                <div className="space-y-2">
                  {p.milestones.map((m, mi) => (
                    <div key={mi} className="flex items-center gap-3">
                      <FileCheck2 size={15} className={m.done ? "text-forest-600" : "text-navy-300"} />
                      <span className={`text-sm ${m.done ? "text-navy-700" : "text-navy-400"}`}>{m.title}</span>
                      <span className="text-xs text-navy-400 ml-auto">{new Date(m.dueDate).toLocaleDateString()}</span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      )}

      {tab === "portfolio" && (
        <Reveal>
          <GlassCard>
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp size={18} className="text-forest-600" />
              <p className="font-semibold text-navy-900">Auto-generated Impact Portfolio</p>
            </div>
            <p className="text-sm text-navy-600 mb-6">
              Generated automatically from resolved projects — export-ready for NAAC / NIRF / institutional reporting.
            </p>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="rounded-xl bg-navy-50 p-4 text-center">
                <p className="text-2xl font-bold text-navy-900">{heiProjects.length}</p>
                <p className="text-xs text-navy-500">Civic problems engaged</p>
              </div>
              <div className="rounded-xl bg-forest-50 p-4 text-center">
                <p className="text-2xl font-bold text-forest-700">{resolvedCount}</p>
                <p className="text-xs text-navy-500">Solutions delivered</p>
              </div>
              <div className="rounded-xl bg-saffron-50 p-4 text-center">
                <p className="text-2xl font-bold text-saffron-700">
                  ₹{heiProjects.reduce((s, p) => s + p.fundingDisbursed, 0).toLocaleString("en-IN")}
                </p>
                <p className="text-xs text-navy-500">Research funding utilised</p>
              </div>
            </div>
          </GlassCard>
        </Reveal>
      )}
    </div>
  );
}
