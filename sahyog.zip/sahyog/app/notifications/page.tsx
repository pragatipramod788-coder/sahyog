"use client";

import { Bell, CheckCircle2, AlertTriangle, GraduationCap, IndianRupee } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";

const notifications = [
  { icon: GraduationCap, tint: "text-forest-700 bg-forest-50", title: "Your report was matched", body: "SAHYOG-RPT-00231 was matched to BIT Mesra, Civil Engineering.", time: "2 hours ago" },
  { icon: CheckCircle2, tint: "text-navy-700 bg-navy-50", title: "Status updated", body: "SAHYOG-RPT-00198 moved to In Progress.", time: "1 day ago" },
  { icon: AlertTriangle, tint: "text-red-700 bg-red-50", title: "SLA warning", body: "SAHYOG-RPT-00176 is nearing its 7-day resolution window.", time: "2 days ago" },
  { icon: IndianRupee, tint: "text-saffron-700 bg-saffron-50", title: "Funding disbursed", body: "₹25,000 disbursed for the water pipeline project in your ward.", time: "4 days ago" },
];

export default function NotificationsPage() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <Reveal>
        <div className="flex items-center gap-3 mb-8">
          <div className="h-11 w-11 rounded-xl bg-navy-900 text-white flex items-center justify-center"><Bell size={20} /></div>
          <h1 className="font-display text-3xl text-navy-950">Notifications</h1>
        </div>
      </Reveal>
      <div className="space-y-3">
        {notifications.map((n, i) => (
          <Reveal key={i} delay={i * 0.05}>
            <GlassCard className="flex items-start gap-4">
              <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${n.tint}`}>
                <n.icon size={18} />
              </div>
              <div>
                <p className="text-sm font-semibold text-navy-900">{n.title}</p>
                <p className="text-sm text-navy-600">{n.body}</p>
                <p className="text-xs text-navy-400 mt-1">{n.time}</p>
              </div>
            </GlassCard>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
