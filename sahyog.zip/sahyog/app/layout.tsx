import type { Metadata } from "next";
import "./globals.css";
import { LanguageProvider } from "@/lib/LanguageContext";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import LogoIntro from "@/components/LogoIntro";

// NOTE: next/font/google requires network access to fonts.googleapis.com at build
// time, which isn't available in every environment (e.g. offline CI, some sandboxes).
// We use system font stacks defined in globals.css instead. To use real Google Fonts
// (Inter / Playfair Display / Noto Sans Devanagari) in an environment with internet
// access, restore the next/font/google imports here — see README "Fonts" section.

export const metadata: Metadata = {
  title: "SAHYOG — Government of Jharkhand | Civic Innovation Platform",
  description:
    "SAHYOG connects citizens, universities, and industry to report, match, fund, and resolve civic problems across Jharkhand — transparently.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans antialiased chakra-bg">
        <LanguageProvider>
          <LogoIntro />
          <Header />
          <main className="min-h-[70vh]">{children}</main>
          <Footer />
        </LanguageProvider>
      </body>
    </html>
  );
}
