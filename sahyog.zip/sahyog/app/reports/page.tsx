"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { MapPin, Clock, ChevronRight, Award, Search, Filter } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import type { Report } from "@/lib/types";

const statusColor: Record<string, string> = {
  Submitted: "bg-navy-100 text-navy-700",
  Matched: "bg-saffron-100 text-saffron-700",
  "In Progress": "bg-blue-100 text-blue-700",
  Resolved: "bg-forest-100 text-forest-700",
  Escalated: "bg-red-100 text-red-700",
};

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [filter, setFilter] = useState<string>("All");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/reports")
      .then((r) => r.json())
      .then((d) => {
        setReports(d.reports);
        setLoading(false);
      });
  }, []);

  const filtered = filter === "All" ? reports : reports.filter((r) => r.status === filter);
  const statuses = ["All", "Submitted", "Matched", "In Progress", "Resolved", "Escalated"];

  return (
    <div className="mx-auto max-w-5xl px-6 py-14">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl text-navy-950">My Reports</h1>
          <p className="text-navy-500 mt-1">Track every report you&apos;ve filed, from submission to resolution.</p>
        </div>
        <GlassCard className="flex items-center gap-3 !p-3 !py-2.5">
          <Award size={20} className="text-saffron-600" />
          <div>
            <p className="text-xs text-navy-500">Community Points</p>
            <p className="text-sm font-bold text-navy-900">340 pts · Community Voice</p>
          </div>
        </GlassCard>
      </div>

      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
        <Filter size={15} className="text-navy-400 shrink-0" />
        {statuses.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`shrink-0 rounded-full px-4 py-1.5 text-xs font-medium border transition-colors ${
              filter === s ? "bg-navy-900 text-white border-navy-900" : "border-navy-200 text-navy-600 hover:bg-navy-50"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-2xl bg-navy-50 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <GlassCard className="text-center py-16">
          <Search size={28} className="mx-auto text-navy-300 mb-3" />
          <p className="text-navy-600">No reports match this filter.</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {filtered.map((r, i) => (
            <motion.div key={r.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
              <Link href={`/reports/${r.id}`}>
                <GlassCard className="flex items-center gap-4 hover:shadow-glass transition-shadow">
                  <div className="hidden sm:flex h-12 w-12 rounded-xl bg-navy-50 items-center justify-center text-navy-700 font-semibold text-xs shrink-0">
                    {r.category.slice(0, 3).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-navy-900 truncate">{r.title}</p>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${statusColor[r.status]}`}>{r.status}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-navy-500 mt-1.5 flex-wrap">
                      <span className="flex items-center gap-1"><MapPin size={12} /> {r.location.district}</span>
                      <span className="flex items-center gap-1"><Clock size={12} /> {new Date(r.createdAt).toLocaleDateString()}</span>
                      <span>ID: {r.id}</span>
                      {r.matchedHEI && <span className="text-forest-700">→ {r.matchedHEI}</span>}
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-navy-300 shrink-0" />
                </GlassCard>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
