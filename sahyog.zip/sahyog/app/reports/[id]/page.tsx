"use client";

import { useEffect, useState, use as usePromise } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin, Calendar, AlertTriangle, ArrowLeft, ThumbsUp, GraduationCap,
  ShieldAlert, X, Loader2, CheckCircle2,
} from "lucide-react";
import GlassCard from "@/components/GlassCard";
import StatusTimeline from "@/components/StatusTimeline";
import type { Report } from "@/lib/types";

export default function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = usePromise(params);
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [showEscalate, setShowEscalate] = useState(false);
  const [reason, setReason] = useState("");
  const [escalating, setEscalating] = useState(false);
  const [grievanceId, setGrievanceId] = useState<string | null>(null);

  function load() {
    fetch(`/api/reports/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setReport(d.report || null);
        setLoading(false);
      });
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const daysLeft = report ? Math.ceil((+new Date(report.slaDeadline) - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
  const slaBreached = daysLeft < 0 && report?.status !== "Resolved" && report?.status !== "Escalated";
  const canEscalate = report && report.status !== "Resolved" && report.status !== "Escalated";

  async function submitEscalation() {
    setEscalating(true);
    const res = await fetch("/api/escalate", {
      method: "POST",
      body: JSON.stringify({ reportId: id, reason: reason || "No action taken within the 7-day SLA window." }),
    });
    const data = await res.json();
    setEscalating(false);
    setGrievanceId(data.grievance?.id || null);
    setReport(data.report);
  }

  if (loading) {
    return <div className="mx-auto max-w-3xl px-6 py-24 text-center text-navy-400">Loading report...</div>;
  }
  if (!report) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-24 text-center">
        <p className="text-navy-600">Report not found.</p>
        <Link href="/reports" className="text-navy-900 font-medium underline mt-3 inline-block">Back to My Reports</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-14">
      <Link href="/reports" className="inline-flex items-center gap-1.5 text-sm text-navy-500 hover:text-navy-900 mb-6">
        <ArrowLeft size={15} /> Back to My Reports
      </Link>

      <div className="flex items-start justify-between gap-4 flex-wrap mb-2">
        <h1 className="font-display text-2xl sm:text-3xl text-navy-950">{report.title}</h1>
        <span className="text-xs font-mono text-navy-400 bg-navy-50 rounded-full px-3 py-1.5">{report.id}</span>
      </div>
      <div className="flex flex-wrap items-center gap-4 text-sm text-navy-500 mb-8">
        <span className="flex items-center gap-1"><MapPin size={14} /> {report.location.address}, {report.location.district}</span>
        <span className="flex items-center gap-1"><Calendar size={14} /> Filed {new Date(report.createdAt).toLocaleDateString()}</span>
        <span className="flex items-center gap-1"><ThumbsUp size={14} /> {report.upvotes} community upvotes</span>
      </div>

      {slaBreached && canEscalate && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-6 flex items-center justify-between gap-4 rounded-2xl bg-red-50 border border-red-200 px-5 py-4 flex-wrap">
          <div className="flex items-center gap-3">
            <AlertTriangle className="text-red-600 shrink-0" size={22} />
            <div>
              <p className="font-semibold text-red-800 text-sm">7-day SLA breached — {Math.abs(daysLeft)} day(s) overdue</p>
              <p className="text-xs text-red-600">This report hasn&apos;t progressed within the standard resolution window.</p>
            </div>
          </div>
          <button
            onClick={() => setShowEscalate(true)}
            className="rounded-xl bg-red-600 text-white px-5 py-2.5 text-sm font-semibold hover:bg-red-700 shrink-0"
          >
            Escalate to Authority
          </button>
        </motion.div>
      )}

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <GlassCard className="!p-4">
          <p className="text-xs text-navy-500 mb-1">Category</p>
          <p className="font-semibold text-navy-900 capitalize">{report.category}</p>
        </GlassCard>
        <GlassCard className="!p-4">
          <p className="text-xs text-navy-500 mb-1">AI Urgency Tag</p>
          <p className="font-semibold text-saffron-700">{report.urgency}</p>
        </GlassCard>
        <GlassCard className="!p-4">
          <p className="text-xs text-navy-500 mb-1">SLA Deadline</p>
          <p className={`font-semibold ${daysLeft < 0 ? "text-red-600" : "text-navy-900"}`}>
            {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d remaining`}
          </p>
        </GlassCard>
      </div>

      {report.matchedHEI && (
        <GlassCard className="mb-8 flex items-center gap-4">
          <div className="h-11 w-11 rounded-xl bg-forest-100 text-forest-700 flex items-center justify-center shrink-0">
            <GraduationCap size={20} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-navy-900">Matched to {report.matchedHEI}</p>
            <p className="text-xs text-navy-500">{report.matchedDept} · AI match confidence {Math.round((report.matchConfidence || 0) * 100)}%</p>
          </div>
        </GlassCard>
      )}

      <GlassCard>
        <p className="font-semibold text-navy-900 mb-6">Status Timeline</p>
        <StatusTimeline timeline={report.timeline} isEscalated={report.status === "Escalated"} />
      </GlassCard>

      {report.description && (
        <GlassCard className="mt-6">
          <p className="font-semibold text-navy-900 mb-2">Citizen Note</p>
          <p className="text-sm text-navy-600 leading-relaxed">{report.description}</p>
        </GlassCard>
      )}

      {canEscalate && !slaBreached && (
        <div className="mt-8 text-center">
          <button onClick={() => setShowEscalate(true)} className="inline-flex items-center gap-2 text-sm font-medium text-red-600 hover:text-red-700 underline underline-offset-4">
            <ShieldAlert size={15} /> This isn&apos;t moving — escalate to a District Officer anyway
          </button>
        </div>
      )}

      {report.grievanceId && (
        <GlassCard className="mt-6 border-red-200 bg-red-50/40">
          <p className="text-sm font-semibold text-red-800">Grievance ID: {report.grievanceId}</p>
          <p className="text-xs text-red-600 mt-1">Routed to a District Nodal Officer with a mandatory 3-day response SLA.</p>
        </GlassCard>
      )}

      {/* Escalation Modal */}
      <AnimatePresence>
        {showEscalate && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-navy-950/50 backdrop-blur-sm px-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="w-full max-w-md">
              <GlassCard className="!bg-white">
                {grievanceId ? (
                  <div className="text-center py-4">
                    <CheckCircle2 className="mx-auto text-forest-600 mb-3" size={36} />
                    <p className="font-semibold text-navy-900 mb-1">Escalated Successfully</p>
                    <p className="text-sm text-navy-500 mb-4">Grievance ID <strong>{grievanceId}</strong> has been created and routed to your District Nodal Officer.</p>
                    <button onClick={() => { setShowEscalate(false); setGrievanceId(null); }} className="w-full rounded-xl bg-navy-900 text-white py-3 text-sm font-semibold">
                      Done
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <p className="font-semibold text-navy-900">Escalate to Authority</p>
                      <button onClick={() => setShowEscalate(false)}><X size={18} className="text-navy-400" /></button>
                    </div>
                    <p className="text-sm text-navy-500 mb-4">
                      This will create a separate Grievance ID and route your report directly to the District Nodal Officer,
                      who is bound by a mandatory 3-day response SLA.
                    </p>
                    <textarea
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      rows={3}
                      placeholder="Why are you escalating? (optional)"
                      className="w-full rounded-xl border border-navy-200 p-3 text-sm outline-none focus:ring-2 focus:ring-navy-300 mb-4"
                    />
                    <button
                      onClick={submitEscalation}
                      disabled={escalating}
                      className="w-full flex items-center justify-center gap-2 rounded-xl bg-red-600 text-white py-3 text-sm font-semibold hover:bg-red-700 disabled:opacity-60"
                    >
                      {escalating ? <Loader2 size={16} className="animate-spin" /> : <ShieldAlert size={16} />}
                      {escalating ? "Escalating..." : "Confirm Escalation"}
                    </button>
                  </>
                )}
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
