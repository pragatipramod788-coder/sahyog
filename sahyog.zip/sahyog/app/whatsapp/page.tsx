"use client";

import { MessageCircle, Smartphone, CheckCircle2 } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";

const chatFlow = [
  { from: "bot", text: "Namaste! 🙏 Main SAHYOG bot hoon. Aap kis tarah ki samasya report karna chahte hain?\n1️⃣ Sadak/Gaddha\n2️⃣ Pani\n3️⃣ Bijli\n4️⃣ Anya" },
  { from: "user", text: "2" },
  { from: "bot", text: "Samajh gaya — Pani se judi samasya. Kripya ek photo bhejein 📷" },
  { from: "user", text: "[photo attached]" },
  { from: "bot", text: "Location share karein ya apna pin code likhein 📍" },
  { from: "user", text: "[location shared]" },
  { from: "bot", text: "Dhanyavaad! Aapki report SAHYOG-RPT-00512 create ho gayi hai. Hamari AI team ise sahi vibhaag se match kar rahi hai. Status track karne ke liye reply karein STATUS." },
];

export default function WhatsAppPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-14 grid lg:grid-cols-2 gap-10 items-start">
      <Reveal>
        <div className="mb-3 h-12 w-12 rounded-xl bg-forest-600 text-white flex items-center justify-center"><MessageCircle size={22} /></div>
        <h1 className="font-display text-3xl text-navy-950 mb-4">Report via WhatsApp</h1>
        <p className="text-navy-600 leading-relaxed mb-6">
          No app, no login required. Message our WhatsApp number and a chatbot walks you through the
          same category → photo → location → description flow as the app — feeding directly into the
          same AI matching backend and status timeline.
        </p>
        <GlassCard className="mb-6 flex items-center gap-4">
          <Smartphone className="text-forest-600" size={28} />
          <div>
            <p className="text-sm text-navy-500">Message us on WhatsApp</p>
            <p className="text-lg font-bold text-navy-900">+91 98XXX XXXXX</p>
          </div>
        </GlassCard>
        <ul className="space-y-2 text-sm text-navy-600">
          <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-forest-600" /> Works on any phone, no smartphone required for basic text flow</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-forest-600" /> Supports Hindi, English, and voice notes</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-forest-600" /> Reply STATUS anytime to check your report's timeline</li>
        </ul>
      </Reveal>

      <Reveal delay={0.1}>
        <div className="rounded-3xl bg-[#e5ddd0] p-4 shadow-glass">
          <div className="bg-forest-700 text-white rounded-xl px-4 py-3 flex items-center gap-3 mb-3">
            <div className="h-9 w-9 rounded-full bg-white/20 flex items-center justify-center"><MessageCircle size={18} /></div>
            <div>
              <p className="text-sm font-semibold">SAHYOG Bot</p>
              <p className="text-[11px] text-white/70">online</p>
            </div>
          </div>
          <div className="space-y-2 max-h-[420px] overflow-y-auto px-1">
            {chatFlow.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-xl px-3 py-2 text-sm whitespace-pre-line ${m.from === "user" ? "bg-forest-100 text-navy-900" : "bg-white text-navy-800"}`}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </div>
  );
}
