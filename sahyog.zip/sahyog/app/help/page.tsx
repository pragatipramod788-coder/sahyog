"use client";

import { HelpCircle, Phone, MessageCircle, Mail, ChevronDown } from "lucide-react";
import { useState } from "react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";

const faqs = [
  { q: "How long does SAHYOG take to resolve a report?", a: "Every report is tracked against a 7-day SLA. If there's no progress within that window, you can escalate directly to a District Nodal Officer." },
  { q: "What is the AI matching engine?", a: "When you submit a report, our AI layer classifies its category and urgency, then matches it to the most relevant university department using semantic similarity search." },
  { q: "Can I report in my local language?", a: "Yes — SAHYOG supports English, Hindi, Santali, and Nagpuri for both text and voice notes." },
  { q: "How is CSR funding tracked?", a: "Every commitment and disbursement is recorded on the public Transparency Ledger, visible without logging in." },
  { q: "What happens after I escalate a report?", a: "A separate Grievance ID is created and routed to your District Nodal Officer, who must respond within 3 days." },
];

export default function HelpPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="mx-auto max-w-3xl px-6 py-14">
      <Reveal className="text-center mb-10">
        <div className="mx-auto h-12 w-12 rounded-xl bg-navy-900 text-white flex items-center justify-center mb-3"><HelpCircle size={22} /></div>
        <h1 className="font-display text-3xl text-navy-950">Help &amp; Support</h1>
        <p className="text-navy-500 mt-2">Everything you need to know about using SAHYOG.</p>
      </Reveal>

      <div className="grid sm:grid-cols-3 gap-4 mb-10">
        <Reveal>
          <GlassCard className="text-center">
            <Phone className="mx-auto text-navy-700 mb-2" size={22} />
            <p className="text-sm font-semibold text-navy-900">1800-XXX-XXXX</p>
            <p className="text-xs text-navy-500">Toll-free helpline</p>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.05}>
          <GlassCard className="text-center">
            <MessageCircle className="mx-auto text-forest-600 mb-2" size={22} />
            <p className="text-sm font-semibold text-navy-900">WhatsApp Bot</p>
            <p className="text-xs text-navy-500">Report &amp; track via chat</p>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.1}>
          <GlassCard className="text-center">
            <Mail className="mx-auto text-saffron-600 mb-2" size={22} />
            <p className="text-sm font-semibold text-navy-900">helpline@sahyog.jharkhand.gov.in</p>
            <p className="text-xs text-navy-500">Email support</p>
          </GlassCard>
        </Reveal>
      </div>

      <Reveal>
        <GlassCard>
          <p className="font-semibold text-navy-900 mb-2">Frequently Asked Questions</p>
          <div className="divide-y divide-navy-50">
            {faqs.map((f, i) => (
              <div key={i}>
                <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between py-4 text-left">
                  <span className="text-sm font-medium text-navy-900">{f.q}</span>
                  <ChevronDown size={16} className={`text-navy-400 transition-transform ${open === i ? "rotate-180" : ""}`} />
                </button>
                {open === i && <p className="text-sm text-navy-600 pb-4 -mt-2">{f.a}</p>}
              </div>
            ))}
          </div>
        </GlassCard>
      </Reveal>
    </div>
  );
}
