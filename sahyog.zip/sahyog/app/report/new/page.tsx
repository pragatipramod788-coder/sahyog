"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Construction, Droplets, Zap, Trash2, HeartPulse, School, Trees, Wheat, MoreHorizontal,
  MapPin, Camera, Mic, Check, ArrowRight, ArrowLeft, Loader2, Sparkles, Square,
} from "lucide-react";
import GlassCard from "@/components/GlassCard";
import { categories } from "@/lib/mockData";
import type { Language } from "@/lib/types";

const icons: Record<string, typeof Construction> = {
  Construction, Droplets, Zap, Trash2, HeartPulse, School, Trees, Wheat, MoreHorizontal,
};

const noteLanguages: { code: Language; label: string }[] = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिन्दी" },
  { code: "sat", label: "ᱥᱟᱱᱛᱟᱲᱤ Santali" },
  { code: "nag", label: "नागपुरी Nagpuri" },
];

const STEPS = ["Category", "Location & Photo", "Describe", "Review"];

export default function NewReportPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState<{ id: string; category: string; urgency: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [category, setCategory] = useState("");
  const [photoName, setPhotoName] = useState("");
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locLoading, setLocLoading] = useState(false);
  const [address, setAddress] = useState("");
  const [noteLang, setNoteLang] = useState<Language>("en");
  const [description, setDescription] = useState("");
  const [recording, setRecording] = useState(false);

  function getLocation() {
    setLocLoading(true);
    if (!navigator.geolocation) {
      setLocation({ lat: 23.3441, lng: 85.3096 });
      setLocLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocLoading(false);
      },
      () => {
        // fallback: Ranchi coordinates for demo
        setLocation({ lat: 23.3441, lng: 85.3096 });
        setLocLoading(false);
      }
    );
  }

  function toggleRecording() {
    setRecording((r) => !r);
    if (!recording) {
      setTimeout(() => {
        setRecording(false);
        if (!description) setDescription((d) => d + " [voice note captured, transcribed via on-device ASR]");
      }, 2200);
    }
  }

  async function handleSubmit() {
    setSubmitting(true);
    const res = await fetch("/api/reports", {
      method: "POST",
      body: JSON.stringify({
        category,
        description: description || "Issue reported via SAHYOG citizen app.",
        language: noteLang,
        location: {
          lat: location?.lat || 23.3441,
          lng: location?.lng || 85.3096,
          address: address || "GPS-tagged location",
          district: "Ranchi",
        },
        photoUrl: photoName ? "/uploads/" + photoName : undefined,
      }),
    });
    const data = await res.json();
    setSubmitting(false);
    setSubmitted({ id: data.report.id, category: data.report.category, urgency: data.report.urgency });
  }

  const selectedCat = categories.find((c) => c.id === category);

  if (submitted) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-6 py-16">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md w-full">
          <GlassCard className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
              className="mx-auto h-16 w-16 rounded-full bg-forest-100 flex items-center justify-center mb-4"
            >
              <Check size={30} className="text-forest-600" />
            </motion.div>
            <h2 className="font-display text-2xl text-navy-950 mb-2">Report Submitted</h2>
            <p className="text-navy-600 text-sm mb-4">Your report has been received and sent to our AI matching engine.</p>
            <div className="rounded-xl bg-navy-50 p-4 text-left space-y-2 mb-6">
              <p className="text-sm"><span className="text-navy-500">Report ID:</span> <span className="font-semibold text-navy-900">{submitted.id}</span></p>
              <p className="text-sm"><span className="text-navy-500">Category:</span> <span className="font-semibold text-navy-900 capitalize">{submitted.category}</span></p>
              <p className="text-sm"><span className="text-navy-500">AI Urgency Tag:</span> <span className="font-semibold text-saffron-700">{submitted.urgency}</span></p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => router.push(`/reports/${submitted.id}`)} className="flex-1 rounded-xl bg-navy-900 text-white py-3 text-sm font-semibold hover:bg-navy-800">
                View Timeline
              </button>
              <button onClick={() => router.push("/reports")} className="flex-1 rounded-xl border border-navy-200 py-3 text-sm font-semibold text-navy-800 hover:bg-navy-50">
                My Reports
              </button>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <h1 className="font-display text-3xl text-navy-950 mb-2 text-center">Report a Problem</h1>
      <p className="text-navy-500 text-center mb-8">Takes less than 2 minutes · Available in your language</p>

      {/* stepper */}
      <div className="flex items-center justify-between mb-10">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-semibold ${
                i < step ? "bg-forest-600 text-white" : i === step ? "bg-navy-900 text-white" : "bg-navy-100 text-navy-400"
              }`}>
                {i < step ? <Check size={14} /> : i + 1}
              </div>
              <span className="text-[11px] text-navy-500 mt-1.5 hidden sm:block">{s}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-[2px] mx-2 ${i < step ? "bg-forest-500" : "bg-navy-100"}`} />}
          </div>
        ))}
      </div>

      <GlassCard>
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <p className="font-semibold text-navy-900 mb-4">What kind of problem are you reporting?</p>
              <div className="grid grid-cols-3 gap-3">
                {categories.map((c) => {
                  const Icon = icons[c.icon] || MoreHorizontal;
                  return (
                    <button
                      key={c.id}
                      onClick={() => setCategory(c.id)}
                      className={`flex flex-col items-center gap-2 rounded-xl border p-4 text-center transition-colors ${
                        category === c.id ? "border-navy-900 bg-navy-50 ring-2 ring-navy-200" : "border-navy-100 hover:bg-navy-50"
                      }`}
                    >
                      <Icon size={22} className={category === c.id ? "text-navy-900" : "text-navy-500"} />
                      <span className="text-xs font-medium text-navy-700 leading-tight">{c.labelEn}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <p className="font-semibold text-navy-900 mb-4">Pin the location and add a photo</p>
              <button
                onClick={getLocation}
                className="w-full flex items-center gap-3 rounded-xl border border-navy-200 p-4 hover:bg-navy-50 mb-3"
              >
                <MapPin size={20} className="text-saffron-600" />
                <div className="text-left flex-1">
                  <p className="text-sm font-medium text-navy-900">
                    {locLoading ? "Fetching your location..." : location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : "Use current GPS location"}
                  </p>
                  <p className="text-xs text-navy-400">{location ? "Location captured" : "Tap to auto-detect"}</p>
                </div>
                {locLoading ? <Loader2 size={18} className="animate-spin text-navy-400" /> : location ? <Check size={18} className="text-forest-600" /> : null}
              </button>
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Landmark / address (optional)"
                className="w-full rounded-xl border border-navy-200 p-3 text-sm outline-none focus:ring-2 focus:ring-navy-300 mb-3"
              />
              <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => setPhotoName(e.target.files?.[0]?.name || "")} />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center gap-3 rounded-xl border border-dashed border-navy-300 p-4 hover:bg-navy-50"
              >
                <Camera size={20} className="text-navy-600" />
                <div className="text-left flex-1">
                  <p className="text-sm font-medium text-navy-900">{photoName || "Attach a photo"}</p>
                  <p className="text-xs text-navy-400">JPEG/PNG, up to 10MB</p>
                </div>
                {photoName && <Check size={18} className="text-forest-600" />}
              </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <p className="font-semibold text-navy-900 mb-4">Describe the issue</p>
              <div className="flex gap-2 mb-3 flex-wrap">
                {noteLanguages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => setNoteLang(l.code)}
                    className={`rounded-full px-3 py-1.5 text-xs font-medium border ${
                      noteLang === l.code ? "bg-navy-900 text-white border-navy-900" : "border-navy-200 text-navy-600 hover:bg-navy-50"
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
                placeholder="Type here, or use the mic to record a voice note..."
                className="w-full rounded-xl border border-navy-200 p-3 text-sm outline-none focus:ring-2 focus:ring-navy-300"
              />
              <button
                onClick={toggleRecording}
                className={`mt-3 w-full flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold transition-colors ${
                  recording ? "bg-red-50 text-red-600 border border-red-200" : "bg-navy-50 text-navy-800 border border-navy-200 hover:bg-navy-100"
                }`}
              >
                {recording ? <Square size={16} /> : <Mic size={16} />}
                {recording ? "Recording... tap to stop" : "Record a voice note instead"}
              </button>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <p className="font-semibold text-navy-900 mb-4">Review before submitting</p>
              <div className="space-y-3">
                <div className="flex items-center justify-between rounded-xl bg-navy-50 p-3">
                  <span className="text-sm text-navy-500">Category</span>
                  <span className="text-sm font-medium text-navy-900">{selectedCat?.labelEn || "—"}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl bg-navy-50 p-3">
                  <span className="text-sm text-navy-500">Location</span>
                  <span className="text-sm font-medium text-navy-900">{location ? `${location.lat.toFixed(3)}, ${location.lng.toFixed(3)}` : "Not captured"}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl bg-navy-50 p-3">
                  <span className="text-sm text-navy-500">Photo</span>
                  <span className="text-sm font-medium text-navy-900">{photoName || "None attached"}</span>
                </div>
                <div className="rounded-xl bg-navy-50 p-3">
                  <span className="text-sm text-navy-500 block mb-1">Description ({noteLanguages.find((l) => l.code === noteLang)?.label})</span>
                  <p className="text-sm font-medium text-navy-900">{description || "No description added."}</p>
                </div>
                <div className="flex items-start gap-2 rounded-xl bg-saffron-50 border border-saffron-200 p-3 text-xs text-saffron-800">
                  <Sparkles size={15} className="mt-0.5 shrink-0" />
                  On submission, our AI engine will auto-tag urgency and match this report to the most relevant university department.
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex gap-3 mt-8">
          {step > 0 && (
            <button onClick={() => setStep((s) => s - 1)} className="flex items-center gap-1.5 rounded-xl border border-navy-200 px-5 py-3 text-sm font-medium text-navy-700 hover:bg-navy-50">
              <ArrowLeft size={16} /> Back
            </button>
          )}
          {step < 3 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={step === 0 && !category}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-navy-900 text-white px-5 py-3 text-sm font-semibold hover:bg-navy-800 disabled:opacity-50"
            >
              Continue <ArrowRight size={16} />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-forest-600 text-white px-5 py-3 text-sm font-semibold hover:bg-forest-700 disabled:opacity-60"
            >
              {submitting ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
              {submitting ? "Submitting..." : "Submit Report"}
            </button>
          )}
        </div>
      </GlassCard>
    </div>
  );
}
