"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  MapPin, Mic, ScanSearch, Handshake, ShieldCheck, TrendingUp,
  Building2, GraduationCap, Factory, Users, ArrowRight, MessageCircle,
  Landmark, BarChart3,
} from "lucide-react";
import Reveal from "@/components/Reveal";
import GlassCard from "@/components/GlassCard";
import Emblem from "@/components/Emblem";
import { useLanguage } from "@/lib/LanguageContext";

const stats = [
  { label: "Reports Filed", labelHi: "दर्ज रिपोर्ट", value: "12,480+" },
  { label: "AI-Matched to HEIs", labelHi: "AI द्वारा मिलान", value: "8,930+" },
  { label: "Districts Covered", labelHi: "कवर जिले", value: "24 / 24" },
  { label: "Funds Tracked", labelHi: "ट्रैक की गई राशि", value: "₹4.7 Cr" },
];

const modules = [
  {
    icon: Users,
    title: "Citizen App",
    titleHi: "नागरिक ऐप",
    desc: "OTP login, multilingual voice/text reporting with photo + GPS, live status timeline, and reputation badges.",
    href: "/report/new",
    color: "from-saffron-500 to-saffron-600",
  },
  {
    icon: Landmark,
    title: "Government Dashboard",
    titleHi: "सरकारी डैशबोर्ड",
    desc: "District heatmaps, AI-match oversight, escalation queue with mandatory SLA, CSR fund tracking.",
    href: "/dashboard/gov",
    color: "from-navy-700 to-navy-900",
  },
  {
    icon: GraduationCap,
    title: "University / HEI Portal",
    titleHi: "विश्वविद्यालय पोर्टल",
    desc: "Matched-problem feed, solution-reuse from similar past cases, proposal submission, impact portfolio.",
    href: "/dashboard/hei",
    color: "from-forest-600 to-forest-800",
  },
  {
    icon: Factory,
    title: "Industry / CSR Portal",
    titleHi: "उद्योग पोर्टल",
    desc: "Opportunity feed, funding & mentorship commitments, milestone tracking, auto CSR compliance reports.",
    href: "/dashboard/industry",
    color: "from-navy-500 to-saffron-600",
  },
];

const steps = [
  { icon: MapPin, title: "1. Report", desc: "Citizen reports an issue with category, photo, GPS location, and a voice or text note in their language." },
  { icon: ScanSearch, title: "2. AI Match", desc: "NLP tags urgency & category; sentence-transformer embeddings match it to the right HEI department and past-solved cases." },
  { icon: Handshake, title: "3. Fund & Solve", desc: "University proposes a solution, industry commits CSR funding, milestones are tracked publicly." },
  { icon: ShieldCheck, title: "4. Resolve or Escalate", desc: "A 7-day SLA watchdog auto-escalates stalled reports to a District Nodal Officer with a dedicated Grievance ID." },
];

export default function LandingPage() {
  const { lang } = useLanguage();

  return (
    <div className="overflow-hidden">
      {/* HERO */}
      <section className="relative pt-16 pb-24 sm:pt-24 sm:pb-32">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-navy-50 via-white to-white" />
        <div className="absolute -top-20 -right-20 h-96 w-96 rounded-full bg-saffron-200/40 blur-3xl -z-10" />
        <div className="absolute -bottom-10 -left-20 h-80 w-80 rounded-full bg-forest-200/40 blur-3xl -z-10" />

        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 rounded-full bg-white border border-navy-100 shadow-glass-sm px-4 py-1.5 text-xs font-medium text-navy-700 mb-6"
            >
              <Emblem size={16} /> SIH26043 · Government of Jharkhand Prototype
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-display text-4xl sm:text-5xl lg:text-[3.4rem] leading-[1.1] text-navy-950"
            >
              Every local problem<br />deserves a{" "}
              <span className="text-gradient-gov">matched solution.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="mt-6 text-lg text-navy-700 max-w-xl leading-relaxed"
            >
              SAHYOG connects citizens, universities, and industry — so civic problems get
              reported, AI-matched to the right research department, funded transparently,
              and resolved. No report is left unanswered.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-8 flex flex-wrap gap-4"
            >
              <Link
                href="/report/new"
                className="group inline-flex items-center gap-2 rounded-full bg-navy-900 text-white px-6 py-3.5 font-semibold shadow-glass hover:bg-navy-800 transition-colors"
              >
                Report a Problem
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/reports"
                className="inline-flex items-center gap-2 rounded-full bg-white border border-navy-200 text-navy-900 px-6 py-3.5 font-semibold hover:bg-navy-50 transition-colors"
              >
                Track My Reports
              </Link>
              <Link
                href="/whatsapp"
                className="inline-flex items-center gap-2 rounded-full bg-forest-600 text-white px-6 py-3.5 font-semibold hover:bg-forest-700 transition-colors"
              >
                <MessageCircle size={18} /> Report via WhatsApp
              </Link>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <GlassCard className="relative">
              <div className="flex items-center justify-between mb-4">
                <p className="font-semibold text-navy-900">Live Platform Pulse</p>
                <span className="flex items-center gap-1.5 text-xs text-forest-700 font-medium">
                  <span className="h-2 w-2 rounded-full bg-forest-500 animate-pulse" /> Live
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {stats.map((s, i) => (
                  <motion.div
                    key={s.label}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + i * 0.1 }}
                    className="rounded-xl bg-white/70 border border-navy-100 p-4"
                  >
                    <p className="text-2xl font-bold text-navy-900">{s.value}</p>
                    <p className="text-xs text-navy-500 mt-1">{lang === "hi" ? s.labelHi : s.label}</p>
                  </motion.div>
                ))}
              </div>
              <div className="mt-4 rounded-xl bg-gradient-to-r from-navy-900 to-navy-700 p-4 text-white flex items-center gap-3">
                <BarChart3 size={22} />
                <p className="text-sm">AI matching engine has an average confidence of <strong>87%</strong> across live matches.</p>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-20 bg-white">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-saffron-600 font-semibold text-sm tracking-wide uppercase mb-2">How SAHYOG works</p>
            <h2 className="font-display text-3xl sm:text-4xl text-navy-950">From a photo on a street to a funded, tracked solution</h2>
          </Reveal>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((s, i) => (
              <Reveal key={s.title} delay={i * 0.1}>
                <div className="h-full rounded-2xl border border-navy-100 bg-navy-50/40 p-6 hover:shadow-glass-sm transition-shadow">
                  <div className="h-11 w-11 rounded-xl bg-navy-900 text-white flex items-center justify-center mb-4">
                    <s.icon size={20} />
                  </div>
                  <p className="font-semibold text-navy-900 mb-2">{s.title}</p>
                  <p className="text-sm text-navy-600 leading-relaxed">{s.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* MODULES */}
      <section className="py-20 chakra-bg">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-forest-700 font-semibold text-sm tracking-wide uppercase mb-2">Four stakeholders, one platform</p>
            <h2 className="font-display text-3xl sm:text-4xl text-navy-950">Built for every role in the civic loop</h2>
          </Reveal>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {modules.map((m, i) => (
              <Reveal key={m.title} delay={i * 0.1}>
                <Link href={m.href} className="group block h-full">
                  <GlassCard className="h-full flex flex-col hover:-translate-y-1.5 transition-transform duration-300">
                    <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${m.color} text-white flex items-center justify-center mb-4 shadow-glass-sm`}>
                      <m.icon size={22} />
                    </div>
                    <p className="font-semibold text-navy-900 mb-2">{lang === "hi" ? m.titleHi : m.title}</p>
                    <p className="text-sm text-navy-600 leading-relaxed flex-1">{m.desc}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-navy-800 group-hover:gap-2 transition-all">
                      Enter portal <ArrowRight size={15} />
                    </span>
                  </GlassCard>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* AI LAYER */}
      <section className="py-20 bg-navy-950 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, #fff 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-12 items-center relative">
          <Reveal>
            <p className="text-saffron-400 font-semibold text-sm tracking-wide uppercase mb-2">The AI layer</p>
            <h2 className="font-display text-3xl sm:text-4xl mb-5">Reports don&apos;t just get filed. They get understood.</h2>
            <p className="text-white/70 leading-relaxed mb-6">
              A Python FastAPI microservice runs sentence-transformer embeddings and FAISS
              similarity search the moment a report is submitted — auto-tagging category and
              urgency, matching it to the most relevant HEI department, and surfacing past-solved
              cases so no institution repeats research from scratch.
            </p>
            <ul className="space-y-3 text-sm text-white/80">
              <li className="flex items-start gap-2"><ShieldCheck size={16} className="mt-0.5 text-forest-400" /> Automatic urgency &amp; category tagging on submission</li>
              <li className="flex items-start gap-2"><ShieldCheck size={16} className="mt-0.5 text-forest-400" /> Embedding-based department matching with confidence scores</li>
              <li className="flex items-start gap-2"><ShieldCheck size={16} className="mt-0.5 text-forest-400" /> Solution-reuse suggestions from similar past-solved reports</li>
              <li className="flex items-start gap-2"><ShieldCheck size={16} className="mt-0.5 text-forest-400" /> Government officers can review and override every AI match</li>
            </ul>
          </Reveal>
          <Reveal delay={0.15}>
            <GlassCard dark className="font-mono text-xs sm:text-sm">
              <p className="text-saffron-300 mb-2">POST /api/match</p>
              <pre className="whitespace-pre-wrap text-white/80 leading-relaxed">{`{
  "report_id": "SAHYOG-RPT-00231",
  "text": "Water pipeline leaking near..."
}

→ {
  "category": "water",
  "urgency": "High",
  "matched_hei": "IIT (ISM) Dhanbad",
  "department": "Water Resources",
  "confidence": 0.91,
  "similar_past_cases": 3
}`}</pre>
            </GlassCard>
          </Reveal>
        </div>
      </section>

      {/* TRANSPARENCY CTA */}
      <section className="py-20 bg-white">
        <div className="mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="rounded-3xl bg-gradient-to-br from-saffron-50 via-white to-forest-50 border border-navy-100 p-10 sm:p-14 grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <p className="text-navy-500 font-semibold text-sm tracking-wide uppercase mb-2">No login needed</p>
                <h2 className="font-display text-3xl text-navy-950 mb-4">Every rupee, every milestone — public.</h2>
                <p className="text-navy-700 leading-relaxed mb-6">
                  The public transparency ledger shows fund flow from industry CSR commitments to
                  disbursement against real milestones, and the outcomes they produced — visible to
                  every citizen, anytime.
                </p>
                <Link href="/transparency" className="inline-flex items-center gap-2 rounded-full bg-navy-900 text-white px-6 py-3 font-semibold hover:bg-navy-800 transition-colors">
                  Open Transparency Ledger <ArrowRight size={16} />
                </Link>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <GlassCard className="text-center">
                  <TrendingUp className="mx-auto text-forest-600 mb-2" size={24} />
                  <p className="text-2xl font-bold text-navy-900">₹4.7 Cr</p>
                  <p className="text-xs text-navy-500">Total tracked funding</p>
                </GlassCard>
                <GlassCard className="text-center">
                  <Building2 className="mx-auto text-navy-700 mb-2" size={24} />
                  <p className="text-2xl font-bold text-navy-900">38</p>
                  <p className="text-xs text-navy-500">Active projects</p>
                </GlassCard>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
