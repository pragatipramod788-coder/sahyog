"use client";

import { Settings as SettingsIcon, Globe, Bell, Shield, LogOut } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import { languages } from "@/lib/i18n";
import { useLanguage } from "@/lib/LanguageContext";

export default function SettingsPage() {
  const { lang, setLang } = useLanguage();

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <Reveal>
        <div className="flex items-center gap-3 mb-8">
          <div className="h-11 w-11 rounded-xl bg-navy-900 text-white flex items-center justify-center"><SettingsIcon size={20} /></div>
          <h1 className="font-display text-3xl text-navy-950">Settings</h1>
        </div>
      </Reveal>

      <Reveal>
        <GlassCard className="mb-4">
          <p className="font-semibold text-navy-900 flex items-center gap-2 mb-4"><Globe size={16} /> Language</p>
          <div className="grid grid-cols-2 gap-2">
            {languages.map((l) => (
              <button
                key={l.code}
                onClick={() => setLang(l.code)}
                className={`rounded-xl border px-4 py-3 text-sm font-medium text-left ${
                  lang === l.code ? "border-navy-900 bg-navy-50" : "border-navy-100 hover:bg-navy-50"
                }`}
              >
                {l.native}
              </button>
            ))}
          </div>
        </GlassCard>
      </Reveal>

      <Reveal delay={0.05}>
        <GlassCard className="mb-4">
          <p className="font-semibold text-navy-900 flex items-center gap-2 mb-4"><Bell size={16} /> Notification Preferences</p>
          {["SLA warnings", "Match updates", "Funding disbursements", "Community activity"].map((n) => (
            <label key={n} className="flex items-center justify-between py-2.5 border-b border-navy-50 last:border-0">
              <span className="text-sm text-navy-700">{n}</span>
              <input type="checkbox" defaultChecked className="h-4 w-4 accent-navy-900" />
            </label>
          ))}
        </GlassCard>
      </Reveal>

      <Reveal delay={0.1}>
        <GlassCard className="mb-4">
          <p className="font-semibold text-navy-900 flex items-center gap-2 mb-4"><Shield size={16} /> Privacy &amp; Data</p>
          <p className="text-sm text-navy-600">Your reports and personal data are handled per the Government of Jharkhand's data protection guidelines. Location data is used only to route reports to the correct district authority.</p>
        </GlassCard>
      </Reveal>

      <Reveal delay={0.15}>
        <button className="w-full flex items-center justify-center gap-2 rounded-xl border border-red-200 text-red-600 py-3 text-sm font-semibold hover:bg-red-50">
          <LogOut size={16} /> Sign Out
        </button>
      </Reveal>
    </div>
  );
}
