"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, IndianRupee, Building2, MapPin, ExternalLink } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import Emblem from "@/components/Emblem";
import type { Project, LedgerEntry } from "@/lib/types";

export default function TransparencyPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);

  useEffect(() => {
    fetch("/api/projects").then((r) => r.json()).then((d) => {
      setProjects(d.projects);
      setLedger(d.ledger);
    });
  }, []);

  const totalFunded = projects.reduce((s, p) => s + p.fundingCommitted, 0);
  const totalDisbursed = projects.reduce((s, p) => s + p.fundingDisbursed, 0);

  return (
    <div className="mx-auto max-w-6xl px-6 py-14">
      <Reveal className="text-center mb-12">
        <div className="flex justify-center mb-3"><Emblem size={48} /></div>
        <p className="text-xs font-semibold uppercase tracking-wide text-forest-600 mb-2">Open to everyone · No login required</p>
        <h1 className="font-display text-3xl sm:text-4xl text-navy-950">Public Transparency Ledger</h1>
        <p className="text-navy-500 max-w-xl mx-auto mt-3">
          Every rupee committed by industry CSR partners, tracked against real milestones and real outcomes,
          for every citizen of Jharkhand to see.
        </p>
      </Reveal>

      <div className="grid sm:grid-cols-3 gap-5 mb-12">
        <Reveal>
          <GlassCard className="text-center">
            <IndianRupee className="mx-auto text-navy-700 mb-2" size={26} />
            <p className="text-2xl font-bold text-navy-900">₹{totalFunded.toLocaleString("en-IN")}</p>
            <p className="text-xs text-navy-500">Total Funding Committed</p>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.05}>
          <GlassCard className="text-center">
            <ShieldCheck className="mx-auto text-forest-600 mb-2" size={26} />
            <p className="text-2xl font-bold text-navy-900">₹{totalDisbursed.toLocaleString("en-IN")}</p>
            <p className="text-xs text-navy-500">Disbursed Against Milestones</p>
          </GlassCard>
        </Reveal>
        <Reveal delay={0.1}>
          <GlassCard className="text-center">
            <Building2 className="mx-auto text-saffron-600 mb-2" size={26} />
            <p className="text-2xl font-bold text-navy-900">{projects.length}</p>
            <p className="text-xs text-navy-500">Active Civic Projects</p>
          </GlassCard>
        </Reveal>
      </div>

      <Reveal>
        <GlassCard className="mb-8">
          <p className="font-semibold text-navy-900 mb-5">Fund Flow — Project by Project</p>
          <div className="space-y-4">
            {projects.map((p) => (
              <div key={p.id} className="rounded-xl border border-navy-100 p-4">
                <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
                  <p className="text-sm font-semibold text-navy-900">{p.title}</p>
                  <span className="text-xs font-medium bg-navy-50 text-navy-700 rounded-full px-2.5 py-1">{p.status}</span>
                </div>
                <p className="text-xs text-navy-500 flex items-center gap-1 mb-3">
                  <MapPin size={11} /> {p.district} · {p.heiName} {p.industryPartner ? `· funded by ${p.industryPartner}` : "· funded by Govt. CSR Pool"}
                </p>
                <div className="h-2 rounded-full bg-navy-50 overflow-hidden mb-1.5">
                  <div className="h-full bg-forest-500" style={{ width: `${Math.round((p.fundingDisbursed / p.fundingCommitted) * 100)}%` }} />
                </div>
                <p className="text-xs text-navy-500">₹{p.fundingDisbursed.toLocaleString("en-IN")} of ₹{p.fundingCommitted.toLocaleString("en-IN")} disbursed</p>
              </div>
            ))}
          </div>
        </GlassCard>
      </Reveal>

      <Reveal delay={0.1}>
        <GlassCard>
          <p className="font-semibold text-navy-900 mb-5">On-record Transaction Ledger</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-navy-400 border-b border-navy-100">
                  <th className="pb-2 font-medium">Tx Hash</th>
                  <th className="pb-2 font-medium">Project</th>
                  <th className="pb-2 font-medium">From</th>
                  <th className="pb-2 font-medium">Amount</th>
                  <th className="pb-2 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {ledger.map((l) => (
                  <tr key={l.id} className="border-b border-navy-50 last:border-0">
                    <td className="py-3 pr-4 font-mono text-xs text-navy-500 flex items-center gap-1">{l.txHash} <ExternalLink size={11} /></td>
                    <td className="py-3 pr-4 text-navy-900">{l.projectTitle.slice(0, 32)}</td>
                    <td className="py-3 pr-4 text-navy-600">{l.from}</td>
                    <td className="py-3 pr-4 text-forest-700">₹{l.amount.toLocaleString("en-IN")}</td>
                    <td className="py-3 pr-4 text-navy-500">{new Date(l.date).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </Reveal>
    </div>
  );
}
