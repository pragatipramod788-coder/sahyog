import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/store";

// POST: request an OTP for a phone number.
// In production this calls an SMS gateway (e.g. MSG91 / Twilio) from the Express layer
// and never returns the OTP itself to the client.
export async function POST(req: NextRequest) {
  const { phone } = await req.json();
  if (!phone || phone.length < 10) {
    return NextResponse.json({ error: "Invalid phone number" }, { status: 400 });
  }
  const otp = String(Math.floor(1000 + Math.random() * 9000));
  getDb().otpStore.set(phone, otp);
  // demo-only: OTP is returned so the prototype is testable without an SMS gateway
  return NextResponse.json({ success: true, otp });
}

// PUT: verify OTP
export async function PUT(req: NextRequest) {
  const { phone, otp, expected } = await req.json();
  const stored = getDb().otpStore.get(phone) || expected;
  const success = otp && stored && otp === stored;
  return NextResponse.json({ success: !!success });
}
