import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/store";
import { aiClassify, aiMatchHEI } from "@/lib/mockData";
import type { Report, TimelineEvent } from "@/lib/types";

function newId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

export async function GET() {
  const db = getDb();
  const reports = [...db.reports].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  return NextResponse.json({ reports });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const db = getDb();

  // --- simulated call to the FastAPI AI-matching microservice ---
  const classification = aiClassify(body.description || "");
  const category = body.category || classification.category;
  const match = aiMatchHEI(category);

  const now = new Date().toISOString();
  const sla = new Date();
  sla.setDate(sla.getDate() + 7);

  const timeline: TimelineEvent[] = [
    { status: "Submitted", timestamp: now, actor: "Citizen" },
    { status: "Matched", timestamp: now, note: `${match.hei} — ${match.dept} (confidence ${Math.round(match.confidence * 100)}%)`, actor: "AI Engine" },
  ];

  const report: Report = {
    id: newId("SAHYOG-RPT"),
    citizenId: "citizen-demo",
    citizenName: "Ravi Kumar",
    title: (body.description || "Untitled report").slice(0, 70),
    category,
    urgency: classification.urgency,
    description: body.description || "",
    language: body.language || "en",
    photoUrl: body.photoUrl,
    location: body.location || { lat: 23.3441, lng: 85.3096, address: "Ranchi", district: "Ranchi" },
    status: "Matched",
    createdAt: now,
    updatedAt: now,
    timeline,
    matchedHEI: match.hei,
    matchedDept: match.dept,
    matchConfidence: match.confidence,
    slaDeadline: sla.toISOString(),
    upvotes: 0,
  };

  db.reports.unshift(report);
  return NextResponse.json({ report });
}
