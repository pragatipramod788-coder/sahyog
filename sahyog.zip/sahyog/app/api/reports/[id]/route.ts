import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/store";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const report = getDb().reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ report });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const db = getDb();
  const report = db.reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (body.status) {
    report.status = body.status;
    report.timeline.push({ status: body.status, timestamp: new Date().toISOString(), actor: body.actor || "System", note: body.note });
    report.updatedAt = new Date().toISOString();
  }
  return NextResponse.json({ report });
}
