import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/store";
import type { Grievance } from "@/lib/types";

function newId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

export async function POST(req: NextRequest) {
  const { reportId, reason } = await req.json();
  const db = getDb();
  const report = db.reports.find((r) => r.id === reportId);
  if (!report) return NextResponse.json({ error: "Report not found" }, { status: 404 });

  const now = new Date().toISOString();
  const deadline = new Date();
  deadline.setDate(deadline.getDate() + 3);

  const grievance: Grievance = {
    id: newId("SAHYOG-GRV"),
    reportId,
    raisedAt: now,
    reason: reason || "No action taken within the 7-day SLA window.",
    assignedOfficer: `District Nodal Officer, ${report.location.district}`,
    district: report.location.district,
    responseDeadline: deadline.toISOString(),
    status: "Open",
  };
  db.grievances.unshift(grievance);

  report.status = "Escalated";
  report.grievanceId = grievance.id;
  report.timeline.push({ status: "Grievance Raised", timestamp: now, note: grievance.reason, actor: "Citizen" });
  report.timeline.push({ status: "Officer Assigned", timestamp: now, note: grievance.assignedOfficer, actor: "System" });
  report.updatedAt = now;

  return NextResponse.json({ grievance, report });
}
