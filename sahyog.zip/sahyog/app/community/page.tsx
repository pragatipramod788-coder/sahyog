"use client";

import { useEffect, useState } from "react";
import { Trophy, MapPin, Award } from "lucide-react";
import GlassCard from "@/components/GlassCard";
import Reveal from "@/components/Reveal";
import type { Report } from "@/lib/types";

const leaderboard = [
  { name: "Sunita Devi", district: "Dhanbad", points: 620, badge: "Civic Champion" },
  { name: "Ravi Kumar", district: "Ranchi", points: 340, badge: "Community Voice" },
  { name: "Amit Oraon", district: "Jamshedpur", points: 310, badge: "First Reporter" },
  { name: "Priya Munda", district: "Bokaro", points: 275, badge: "Community Voice" },
  { name: "Sanjay Mahato", district: "Deoghar", points: 210, badge: "First Reporter" },
];

export default function CommunityPage() {
  const [reports, setReports] = useState<Report[]>([]);

  useEffect(() => {
    fetch("/api/reports").then((r) => r.json()).then((d) => setReports(d.reports));
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-6 py-14">
      <Reveal className="mb-8">
        <h1 className="font-display text-3xl text-navy-950">Community Map &amp; Leaderboard</h1>
        <p className="text-navy-500 mt-1">See what's being reported near you, and who's driving change.</p>
      </Reveal>

      <div className="grid lg:grid-cols-3 gap-6">
        <Reveal className="lg:col-span-2">
          <GlassCard className="h-full">
            <p className="font-semibold text-navy-900 mb-4 flex items-center gap-2"><MapPin size={16} /> Community Map</p>
            <div className="relative h-[420px] rounded-xl bg-gradient-to-br from-navy-50 to-forest-50 overflow-hidden border border-navy-100">
              {reports.map((r, i) => (
                <div
                  key={r.id}
                  title={r.title}
                  className="absolute h-3 w-3 rounded-full bg-saffron-500 ring-4 ring-saffron-200 animate-pulse cursor-pointer"
                  style={{ left: `${10 + ((i * 37) % 80)}%`, top: `${15 + ((i * 53) % 70)}%` }}
                />
              ))}
              <p className="absolute bottom-3 left-3 text-[11px] text-navy-400">Illustrative map — integrate Mapbox/Leaflet with live lat/lng in production.</p>
            </div>
          </GlassCard>
        </Reveal>

        <Reveal delay={0.1}>
          <GlassCard className="h-full">
            <p className="font-semibold text-navy-900 mb-4 flex items-center gap-2"><Trophy size={16} className="text-saffron-600" /> Citizen Leaderboard</p>
            <div className="space-y-3">
              {leaderboard.map((u, i) => (
                <div key={u.name} className="flex items-center gap-3">
                  <span className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? "bg-saffron-500 text-white" : "bg-navy-50 text-navy-600"}`}>{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-navy-900 truncate">{u.name}</p>
                    <p className="text-xs text-navy-400">{u.district} · <Award size={10} className="inline mb-0.5" /> {u.badge}</p>
                  </div>
                  <span className="text-sm font-bold text-navy-800">{u.points}</span>
                </div>
              ))}
            </div>
          </GlassCard>
        </Reveal>
      </div>
    </div>
  );
}
