// Server-side in-memory store standing in for MongoDB Atlas during prototyping.
// Swap this module's internals for a real `mongodb` driver connection (see README)
// without changing any API route signatures.
import { seedReports, seedGrievances, seedProjects, seedLedger, demoUsers } from "./mockData";
import type { Report, Grievance, Project, LedgerEntry, AppUser, Notification } from "./types";

interface DB {
  reports: Report[];
  grievances: Grievance[];
  projects: Project[];
  ledger: LedgerEntry[];
  users: AppUser[];
  notifications: Notification[];
  otpStore: Map<string, string>;
}

const globalForDb = globalThis as unknown as { __sahyogDb?: DB };

function buildDb(): DB {
  const reports = seedReports();
  const grievances = seedGrievances(reports);
  const projects = seedProjects(reports);
  const ledger = seedLedger(projects);
  return {
    reports,
    grievances,
    projects,
    ledger,
    users: [...demoUsers],
    notifications: [],
    otpStore: new Map(),
  };
}

export function getDb(): DB {
  if (!globalForDb.__sahyogDb) {
    globalForDb.__sahyogDb = buildDb();
  }
  return globalForDb.__sahyogDb;
}
