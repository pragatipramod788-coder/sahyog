export type Role = "citizen" | "government" | "university" | "industry";

export type ReportStatus = "Submitted" | "Matched" | "In Progress" | "Resolved" | "Escalated";

export type Language = "en" | "hi" | "sat" | "nag";

export interface Category {
  id: string;
  labelEn: string;
  labelHi: string;
  icon: string;
}

export interface TimelineEvent {
  status: ReportStatus | "Grievance Raised" | "Officer Assigned";
  timestamp: string;
  note?: string;
  actor?: string;
}

export interface Report {
  id: string;
  citizenId: string;
  citizenName: string;
  title: string;
  category: string;
  urgency: "Low" | "Medium" | "High" | "Critical";
  description: string;
  language: Language;
  photoUrl?: string;
  location: { lat: number; lng: number; address: string; district: string };
  status: ReportStatus;
  createdAt: string;
  updatedAt: string;
  timeline: TimelineEvent[];
  matchedHEI?: string;
  matchedDept?: string;
  matchConfidence?: number;
  slaDeadline: string;
  grievanceId?: string;
  upvotes: number;
}

export interface Grievance {
  id: string;
  reportId: string;
  raisedAt: string;
  reason: string;
  assignedOfficer: string;
  district: string;
  responseDeadline: string;
  status: "Open" | "Acknowledged" | "Resolved";
}

export interface Project {
  id: string;
  reportId: string;
  title: string;
  heiName: string;
  department: string;
  industryPartner?: string;
  fundingCommitted: number;
  fundingDisbursed: number;
  status: "Proposed" | "Funded" | "Active" | "Completed";
  milestones: { title: string; dueDate: string; done: boolean }[];
  district: string;
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  projectId: string;
  projectTitle: string;
  from: string;
  amount: number;
  purpose: string;
  date: string;
  txHash: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
}

export interface AppUser {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  role: Role;
  approved: boolean;
  org?: string;
  district?: string;
  badges: string[];
  points: number;
}
