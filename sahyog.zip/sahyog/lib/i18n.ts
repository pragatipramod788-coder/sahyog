import type { Language } from "./types";

export const languages: { code: Language; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिन्दी" },
  { code: "sat", label: "Santali", native: "ᱥᱟᱱᱛᱟᱲᱤ" },
  { code: "nag", label: "Nagpuri", native: "नागपुरी" },
];

type Dict = Record<string, { en: string; hi: string; sat?: string; nag?: string }>;

export const dict: Dict = {
  tagline: {
    en: "Report. Match. Resolve. Together.",
    hi: "रिपोर्ट करें। जोड़ें। समाधान करें। साथ मिलकर।",
    sat: "रिपोर्ट काओ। सामेल काओ। दोहड़ काओ।",
    nag: "रिपोर्ट करा। जोड़ा। समाधान करा। मिलजुल के।",
  },
  govLine1: { en: "Government of Jharkhand", hi: "झारखंड सरकार" },
  govLine2: { en: "Department of Higher & Technical Education", hi: "उच्च एवं तकनीकी शिक्षा विभाग" },
  heroTitle: {
    en: "Every local problem deserves a matched solution.",
    hi: "हर स्थानीय समस्या का एक सही समाधान होना चाहिए।",
  },
  heroSub: {
    en: "SAHYOG connects citizens, universities, and industry so that civic problems are reported, AI-matched to the right research department, funded transparently, and resolved — with no report left unanswered.",
    hi: "साहयोग नागरिकों, विश्वविद्यालयों और उद्योग को जोड़ता है ताकि नागरिक समस्याओं की रिपोर्ट हो, AI द्वारा सही विभाग से मिलान हो, पारदर्शी रूप से वित्तपोषण हो और समाधान हो — कोई भी रिपोर्ट अनुत्तरित न रहे।",
  },
  reportProblem: { en: "Report a Problem", hi: "समस्या दर्ज करें" },
  trackReports: { en: "Track My Reports", hi: "मेरी रिपोर्ट देखें" },
  loginCitizen: { en: "Citizen Login", hi: "नागरिक लॉगिन" },
  govPortal: { en: "Government Login", hi: "सरकारी लॉगिन" },
  heiPortal: { en: "University / HEI Login", hi: "विश्वविद्यालय लॉगिन" },
  industryPortal: { en: "Industry / CSR Login", hi: "उद्योग लॉगिन" },
  transparency: { en: "Public Transparency", hi: "सार्वजनिक पारदर्शिता" },
};

export function t(key: keyof typeof dict, lang: Language): string {
  const entry = dict[key];
  if (!entry) return key;
  return entry[lang] || entry.en;
}
