"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { Language } from "./types";
import { t as translate } from "./i18n";

interface Ctx {
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: Parameters<typeof translate>[0]) => string;
}

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>("en");

  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem("sahyog_lang") : null;
    if (saved) setLangState(saved as Language);
  }, []);

  const setLang = (l: Language) => {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("sahyog_lang", l);
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t: (key) => translate(key, lang) }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
