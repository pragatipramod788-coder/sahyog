import type { Category, Report, Grievance, Project, LedgerEntry, AppUser, TimelineEvent } from "./types";

export const categories: Category[] = [
  { id: "roads", labelEn: "Roads & Potholes", labelHi: "सड़क एवं गड्ढे", icon: "Construction" },
  { id: "water", labelEn: "Water Supply", labelHi: "जल आपूर्ति", icon: "Droplets" },
  { id: "electricity", labelEn: "Electricity", labelHi: "बिजली", icon: "Zap" },
  { id: "sanitation", labelEn: "Sanitation & Waste", labelHi: "स्वच्छता एवं कचरा", icon: "Trash2" },
  { id: "health", labelEn: "Public Health", labelHi: "सार्वजनिक स्वास्थ्य", icon: "HeartPulse" },
  { id: "education", labelEn: "Education Infra", labelHi: "शिक्षा अवसंरचना", icon: "School" },
  { id: "environment", labelEn: "Environment & Forest", labelHi: "पर्यावरण एवं वन", icon: "Trees" },
  { id: "agriculture", labelEn: "Agriculture", labelHi: "कृषि", icon: "Wheat" },
  { id: "other", labelEn: "Other", labelHi: "अन्य", icon: "MoreHorizontal" },
];

export const districts = [
  "Ranchi", "Jamshedpur (East Singhbhum)", "Dhanbad", "Bokaro", "Deoghar",
  "Hazaribagh", "Giridih", "Palamu", "Gumla", "Dumka",
];

const heiList = [
  { name: "BIT Mesra", depts: ["Civil Engineering", "Environmental Sci.", "CSE"] },
  { name: "IIT (ISM) Dhanbad", depts: ["Mining Engineering", "Environmental Engg.", "Water Resources"] },
  { name: "NIT Jamshedpur", depts: ["Civil Engineering", "Electrical Engg."] },
  { name: "Ranchi University", depts: ["Public Health", "Sociology", "Botany"] },
  { name: "Central University of Jharkhand", depts: ["Environmental Studies", "Rural Development"] },
];

function id(prefix: string, n: number) {
  return `${prefix}-${String(n).padStart(5, "0")}`;
}

function daysAgo(n: number) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
}
function daysFromNow(n: number) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString();
}

// --- AI matching simulation (stands in for the FastAPI sentence-transformer + FAISS service) ---
const KEYWORD_MAP: { keywords: string[]; category: string; urgency: Report["urgency"] }[] = [
  { keywords: ["pothole", "road", "crack", "गड्ढ", "सड़क"], category: "roads", urgency: "Medium" },
  { keywords: ["water", "pipeline", "leak", "पानी", "जल"], category: "water", urgency: "High" },
  { keywords: ["electric", "wire", "transformer", "बिजली"], category: "electricity", urgency: "Critical" },
  { keywords: ["garbage", "waste", "drain", "कचरा", "गंदगी"], category: "sanitation", urgency: "Medium" },
  { keywords: ["hospital", "disease", "health", "स्वास्थ्य"], category: "health", urgency: "High" },
  { keywords: ["school", "college", "शिक्षा", "स्कूल"], category: "education", urgency: "Low" },
  { keywords: ["forest", "tree", "pollution", "पर्यावरण"], category: "environment", urgency: "Medium" },
  { keywords: ["crop", "farm", "irrigation", "कृषि", "फसल"], category: "agriculture", urgency: "Medium" },
];

export function aiClassify(text: string): { category: string; urgency: Report["urgency"] } {
  const lower = text.toLowerCase();
  for (const rule of KEYWORD_MAP) {
    if (rule.keywords.some((k) => lower.includes(k))) return { category: rule.category, urgency: rule.urgency };
  }
  return { category: "other", urgency: "Medium" };
}

export function aiMatchHEI(category: string): { hei: string; dept: string; confidence: number } {
  const pool = heiList.filter((h) =>
    category === "water" || category === "agriculture" || category === "environment"
      ? h.depts.some((d) => /Environ|Water|Rural/.test(d))
      : category === "electricity"
      ? h.depts.some((d) => /Electrical|CSE/.test(d))
      : category === "health"
      ? h.depts.some((d) => /Public Health|Sociology/.test(d))
      : true
  );
  const chosen = (pool.length ? pool : heiList)[Math.floor(Math.random() * (pool.length ? pool.length : heiList.length))];
  const dept = chosen.depts[Math.floor(Math.random() * chosen.depts.length)];
  const confidence = Math.round((0.78 + Math.random() * 0.2) * 100) / 100;
  return { hei: chosen.name, dept, confidence };
}

// --- Seed reports ---
export function seedReports(): Report[] {
  const titles = [
    "Large pothole causing accidents near market road",
    "No water supply for 5 days in ward 12",
    "Exposed transformer wire near school",
    "Garbage pile up near community drain",
    "Rising waterborne illness cases in village",
    "School building roof leaking during rains",
    "Illegal dumping polluting local stream",
    "Crop damage due to irregular canal irrigation",
  ];
  const reports: Report[] = titles.map((title, i) => {
    const { category, urgency } = aiClassify(title);
    const created = daysAgo(9 - i);
    const status: Report["status"] = i < 2 ? "Submitted" : i < 4 ? "Matched" : i < 6 ? "In Progress" : "Resolved";
    const match = status !== "Submitted" ? aiMatchHEI(category) : null;
    const timeline: TimelineEvent[] = [{ status: "Submitted", timestamp: created, actor: "Citizen" }];
    if (match) timeline.push({ status: "Matched", timestamp: daysAgo(9 - i - 1), note: `${match.hei} — ${match.dept}`, actor: "AI Engine" });
    if (status === "In Progress" || status === "Resolved") timeline.push({ status: "In Progress", timestamp: daysAgo(9 - i - 2), actor: match?.hei });
    if (status === "Resolved") timeline.push({ status: "Resolved", timestamp: daysAgo(9 - i - 3), actor: match?.hei });

    return {
      id: id("SAHYOG-RPT", i + 1),
      citizenId: "citizen-demo",
      citizenName: ["Ravi Kumar", "Sunita Devi", "Amit Oraon", "Priya Munda", "Sanjay Mahato", "Kiran Soren", "Deepak Yadav", "Meena Kumari"][i],
      title,
      category,
      urgency,
      description: title + ". Reported via SAHYOG citizen app with photo and GPS evidence.",
      language: "en",
      photoUrl: undefined,
      location: {
        lat: 23.35 + Math.random() * 0.6,
        lng: 85.3 + Math.random() * 0.7,
        address: "Near local market, Ward " + (i + 3),
        district: districts[i % districts.length],
      },
      status,
      createdAt: created,
      updatedAt: timeline[timeline.length - 1].timestamp,
      timeline,
      matchedHEI: match?.hei,
      matchedDept: match?.dept,
      matchConfidence: match?.confidence,
      slaDeadline: daysFromNow(7 - (9 - i)),
      upvotes: Math.floor(Math.random() * 40),
    };
  });
  return reports;
}

export function seedGrievances(reports: Report[]): Grievance[] {
  return reports.slice(0, 1).map((r, i) => ({
    id: id("SAHYOG-GRV", i + 1),
    reportId: r.id,
    raisedAt: daysAgo(1),
    reason: "No action taken within 7-day SLA window.",
    assignedOfficer: "District Nodal Officer, " + r.location.district,
    district: r.location.district,
    responseDeadline: daysFromNow(3),
    status: "Open",
  }));
}

export function seedProjects(reports: Report[]): Project[] {
  return reports
    .filter((r) => r.matchedHEI)
    .map((r, i) => ({
      id: id("SAHYOG-PRJ", i + 1),
      reportId: r.id,
      title: "Solution for: " + r.title,
      heiName: r.matchedHEI!,
      department: r.matchedDept!,
      industryPartner: i % 2 === 0 ? "Tata Steel Foundation" : undefined,
      fundingCommitted: 50000 + i * 25000,
      fundingDisbursed: r.status === "Resolved" ? 50000 + i * 25000 : Math.floor((50000 + i * 25000) * 0.4),
      status: r.status === "Resolved" ? "Completed" : r.status === "In Progress" ? "Active" : "Funded",
      milestones: [
        { title: "Site survey & assessment", dueDate: daysFromNow(5), done: true },
        { title: "Solution design & approval", dueDate: daysFromNow(15), done: r.status !== "Matched" },
        { title: "Implementation", dueDate: daysFromNow(30), done: r.status === "Resolved" },
      ],
      district: r.location.district,
      createdAt: r.createdAt,
    }));
}

export function seedLedger(projects: Project[]): LedgerEntry[] {
  return projects.map((p, i) => ({
    id: id("SAHYOG-TXN", i + 1),
    projectId: p.id,
    projectTitle: p.title,
    from: p.industryPartner || "Govt. of Jharkhand CSR Pool",
    amount: p.fundingDisbursed,
    purpose: "Milestone-based disbursement",
    date: p.createdAt,
    txHash: "0x" + Math.random().toString(16).slice(2, 10) + Math.random().toString(16).slice(2, 10),
  }));
}

export const demoUsers: AppUser[] = [
  { id: "citizen-demo", name: "Ravi Kumar", phone: "+91 98765 43210", role: "citizen", approved: true, district: "Ranchi", badges: ["First Reporter", "Community Voice"], points: 340 },
  { id: "gov-demo", name: "Dist. Nodal Officer", role: "government", approved: true, district: "Ranchi", badges: [], points: 0 },
  { id: "hei-demo", name: "Dr. A. Sharma", org: "BIT Mesra", role: "university", approved: true, badges: [], points: 0 },
  { id: "industry-demo", name: "CSR Lead", org: "Tata Steel Foundation", role: "industry", approved: true, badges: [], points: 0 },
];
