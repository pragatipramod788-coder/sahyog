"use client";

import { useState } from "react";
import { Languages, Check } from "lucide-react";
import { languages } from "@/lib/i18n";
import { useLanguage } from "@/lib/LanguageContext";

export default function LanguageToggle() {
  const { lang, setLang } = useLanguage();
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 rounded-full border border-navy-200 bg-white/70 px-3 py-1.5 text-xs font-medium text-navy-800 hover:bg-white transition-colors"
      >
        <Languages size={14} />
        {languages.find((l) => l.code === lang)?.native}
      </button>
      {open && (
        <div
          className="absolute right-0 mt-2 w-40 rounded-xl border border-navy-100 bg-white shadow-glass overflow-hidden z-50"
          onMouseLeave={() => setOpen(false)}
        >
          {languages.map((l) => (
            <button
              key={l.code}
              onClick={() => {
                setLang(l.code);
                setOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 text-sm hover:bg-navy-50 text-left"
            >
              <span>{l.native}</span>
              {lang === l.code && <Check size={14} className="text-forest-600" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
