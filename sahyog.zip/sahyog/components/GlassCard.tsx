import { ReactNode } from "react";
import clsx from "clsx";

export default function GlassCard({
  children,
  className,
  dark = false,
}: {
  children: ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <div
      className={clsx(
        dark ? "glass-dark text-white" : "glass",
        "rounded-2xl shadow-glass-sm p-6",
        className
      )}
    >
      {children}
    </div>
  );
}
