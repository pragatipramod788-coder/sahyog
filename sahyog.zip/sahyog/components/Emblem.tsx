"use client";

// An original, stylised "civic chakra" emblem for SAHYOG — inspired by the
// visual language of Indian government portals (a wheel + shield + laurel)
// without reproducing the official State Emblem of India.
export default function Emblem({ size = 44, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      role="img"
      aria-label="SAHYOG emblem"
    >
      <defs>
        <linearGradient id="emblemNavy" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#193f85" />
          <stop offset="100%" stopColor="#0B3D91" />
        </linearGradient>
        <linearGradient id="emblemSaffron" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ff9f1c" />
          <stop offset="100%" stopColor="#f78310" />
        </linearGradient>
      </defs>

      {/* laurel */}
      <path d="M8 50c0-8 6-16 14-19-4 8-4 14 0 21-9-1-14 -2-14 -2z" fill="#268f54" opacity="0.85" />
      <path d="M92 50c0-8-6-16-14-19 4 8 4 14 0 21 9-1 14-2 14-2z" fill="#268f54" opacity="0.85" />

      {/* outer ring */}
      <circle cx="50" cy="50" r="38" fill="none" stroke="url(#emblemNavy)" strokeWidth="4" />
      <circle cx="50" cy="50" r="38" fill="none" stroke="url(#emblemSaffron)" strokeWidth="1.5" strokeDasharray="2 4" />

      {/* chakra spokes */}
      <g stroke="url(#emblemNavy)" strokeWidth="2">
        {Array.from({ length: 24 }).map((_, i) => {
          const angle = (i * 360) / 24;
          const rad = (angle * Math.PI) / 180;
          const x2 = 50 + 30 * Math.cos(rad);
          const y2 = 50 + 30 * Math.sin(rad);
          return <line key={i} x1="50" y1="50" x2={x2} y2={y2} />;
        })}
      </g>
      <circle cx="50" cy="50" r="30" fill="none" stroke="url(#emblemNavy)" strokeWidth="2.5" />
      <circle cx="50" cy="50" r="9" fill="url(#emblemSaffron)" />
      <circle cx="50" cy="50" r="9" fill="none" stroke="#fff" strokeWidth="1" />

      {/* shield base */}
      <path d="M50 78c10-4 16-11 16-20V44l-16-6-16 6v14c0 9 6 16 16 20z" fill="url(#emblemNavy)" opacity="0.9" />
      <path d="M50 72c6-3 10-7 10-14v-9l-10-4-10 4v9c0 7 4 11 10 14z" fill="#fff" opacity="0.9" />
      <text x="50" y="63" textAnchor="middle" fontSize="11" fontWeight="700" fill="#0B3D91" fontFamily="Georgia, serif">S</text>
    </svg>
  );
}
