"use client";

import { motion } from "framer-motion";
import { CheckCircle2, Circle, AlertTriangle } from "lucide-react";
import type { TimelineEvent } from "@/lib/types";

const STAGES = ["Submitted", "Matched", "In Progress", "Resolved"];

export default function StatusTimeline({ timeline, isEscalated }: { timeline: TimelineEvent[]; isEscalated?: boolean }) {
  const reached = new Set(timeline.map((e) => e.status));
  const lastReachedIndex = STAGES.reduce(
    (acc, s, i) => (reached.has(s as TimelineEvent["status"]) ? i : acc),
    -1
  );

  return (
    <div>
      <div className="flex items-center">
        {STAGES.map((stage, i) => {
          const done = i <= lastReachedIndex;
          const isLast = i === STAGES.length - 1;
          return (
            <div key={stage} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center">
                <motion.div
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                  className={`h-9 w-9 rounded-full flex items-center justify-center ${
                    done ? "bg-forest-600 text-white" : "bg-white border-2 border-navy-100 text-navy-300"
                  }`}
                >
                  {done ? <CheckCircle2 size={18} /> : <Circle size={16} />}
                </motion.div>
                <span className={`mt-2 text-[11px] font-medium text-center w-20 ${done ? "text-navy-900" : "text-navy-400"}`}>
                  {stage}
                </span>
              </div>
              {!isLast && (
                <div className="flex-1 h-[3px] mx-1 rounded-full overflow-hidden bg-navy-100">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: i < lastReachedIndex ? "100%" : "0%" }}
                    transition={{ delay: i * 0.15, duration: 0.5 }}
                    className="h-full bg-forest-600"
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {isEscalated && (
        <div className="mt-6 flex items-center gap-2 rounded-xl bg-saffron-50 border border-saffron-200 px-4 py-3 text-saffron-800 text-sm">
          <AlertTriangle size={18} />
          This report has been escalated beyond the 7-day SLA and routed to a District Nodal Officer.
        </div>
      )}

      <ol className="mt-8 space-y-4 border-l-2 border-navy-100 pl-5">
        {timeline.map((event, i) => (
          <li key={i} className="relative">
            <span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-navy-700 ring-4 ring-white" />
            <p className="text-sm font-semibold text-navy-900">{event.status}</p>
            {event.note && <p className="text-sm text-navy-600">{event.note}</p>}
            <p className="text-xs text-navy-400 mt-0.5">
              {new Date(event.timestamp).toLocaleString()} {event.actor ? `· ${event.actor}` : ""}
            </p>
          </li>
        ))}
      </ol>
    </div>
  );
}
