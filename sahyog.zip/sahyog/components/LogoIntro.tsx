"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Emblem from "./Emblem";

const SESSION_KEY = "sahyog_intro_shown";

export default function LogoIntro() {
  const [phase, setPhase] = useState<"idle" | "center" | "split" | "done">("idle");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const alreadyShown = sessionStorage.getItem(SESSION_KEY);
    if (alreadyShown) {
      setPhase("done");
      return;
    }
    setPhase("center");
    const t1 = setTimeout(() => setPhase("split"), 1400);
    const t2 = setTimeout(() => {
      setPhase("done");
      sessionStorage.setItem(SESSION_KEY, "1");
    }, 2500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (phase === "done") return null;

  return (
    <AnimatePresence>
      {(
        <div className="fixed inset-0 z-[100] pointer-events-none">
          {/* left panel */}
          <motion.div
            className="absolute top-0 left-0 h-full w-1/2 bg-navy-900"
            animate={phase === "split" ? { x: "-100%" } : { x: 0 }}
            transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }}
          />
          {/* right panel */}
          <motion.div
            className="absolute top-0 right-0 h-full w-1/2 bg-navy-900"
            animate={phase === "split" ? { x: "100%" } : { x: 0 }}
            transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }}
          />
          {/* saffron/green accent lines that shoot outward on split */}
          <motion.div
            className="absolute left-1/2 top-0 h-full w-[3px] bg-saffron-500 -translate-x-1/2"
            animate={phase === "split" ? { scaleY: 0, opacity: 0 } : { scaleY: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          />

          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
            <motion.div
              initial={{ scale: 0.4, opacity: 0, rotate: -30 }}
              animate={
                phase === "split"
                  ? { scale: 1.15, opacity: 0 }
                  : { scale: 1, opacity: 1, rotate: 0 }
              }
              transition={{ duration: phase === "split" ? 0.6 : 0.9, ease: "easeOut" }}
            >
              <Emblem size={96} />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={phase === "split" ? { opacity: 0 } : { opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="text-center"
            >
              <p className="text-white font-display text-2xl tracking-wide">SAHYOG</p>
              <p className="text-saffron-300 text-xs tracking-[0.3em] uppercase mt-1">Govt. of Jharkhand</p>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
