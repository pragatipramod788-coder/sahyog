import Link from "next/link";
import Emblem from "./Emblem";

export default function Footer() {
  return (
    <footer className="bg-navy-950 text-white/70 mt-24">
      <div className="tricolor-bar" />
      <div className="mx-auto max-w-7xl px-6 py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Emblem size={32} />
            <span className="font-display text-white text-lg">SAHYOG</span>
          </div>
          <p className="text-sm text-white/50 leading-relaxed">
            A civic-innovation platform of the Government of Jharkhand connecting citizens,
            universities, and industry to solve local problems — transparently, and on record.
          </p>
        </div>
        <div>
          <p className="text-white text-sm font-semibold mb-3">Platform</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/report/new" className="hover:text-white">Report a Problem</Link></li>
            <li><Link href="/reports" className="hover:text-white">My Reports</Link></li>
            <li><Link href="/transparency" className="hover:text-white">Transparency Ledger</Link></li>
            <li><Link href="/whatsapp" className="hover:text-white">WhatsApp Reporting</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-white text-sm font-semibold mb-3">Portals</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/dashboard/gov" className="hover:text-white">Government Dashboard</Link></li>
            <li><Link href="/dashboard/hei" className="hover:text-white">University / HEI Portal</Link></li>
            <li><Link href="/dashboard/industry" className="hover:text-white">Industry / CSR Portal</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-white text-sm font-semibold mb-3">Contact</p>
          <ul className="space-y-2 text-sm text-white/60">
            <li>Directorate of Higher &amp; Technical Education</li>
            <li>Project Bhawan, Dhurwa, Ranchi — 834004</li>
            <li>helpline@sahyog.jharkhand.gov.in (demo)</li>
            <li>1800-XXX-XXXX (Toll Free, demo)</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Government of Jharkhand · SAHYOG (SIH26043) — Prototype build, not an official production system.
      </div>
    </footer>
  );
}
