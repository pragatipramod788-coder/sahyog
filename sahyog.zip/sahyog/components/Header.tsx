"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, Bell, User } from "lucide-react";
import Emblem from "./Emblem";
import LanguageToggle from "./LanguageToggle";
import { useLanguage } from "@/lib/LanguageContext";

const navItems = [
  { href: "/report/new", label: { en: "Report a Problem", hi: "समस्या दर्ज करें" } },
  { href: "/reports", label: { en: "My Reports", hi: "मेरी रिपोर्ट" } },
  { href: "/dashboard/gov", label: { en: "Government", hi: "सरकार" } },
  { href: "/dashboard/hei", label: { en: "University", hi: "विश्वविद्यालय" } },
  { href: "/dashboard/industry", label: { en: "Industry", hi: "उद्योग" } },
  { href: "/transparency", label: { en: "Transparency", hi: "पारदर्शिता" } },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const { lang } = useLanguage();

  return (
    <header className="sticky top-0 z-50">
      {/* top govt strip */}
      <div className="bg-navy-950 text-white/80 text-[11px]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-1.5 flex items-center justify-between">
          <span>{lang === "hi" ? "भारत सरकार का उपक्रम | झारखंड राज्य" : "An initiative of the Government of Jharkhand"}</span>
          <div className="hidden sm:flex items-center gap-4">
            <Link href="/help" className="hover:text-white">{lang === "hi" ? "सहायता" : "Help"}</Link>
            <Link href="/settings" className="hover:text-white">{lang === "hi" ? "सेटिंग्स" : "Settings"}</Link>
            <span className="text-white/40">|</span>
            <span>A+ A A-</span>
          </div>
        </div>
      </div>

      {/* main header */}
      <div className="glass border-b border-navy-100">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex items-center justify-between py-2.5">
            <Link href="/" className="flex items-center gap-3">
              <Emblem size={42} />
              <div className="leading-tight">
                <p className="font-display text-lg sm:text-xl text-navy-900 tracking-tight">SAHYOG <span className="text-saffron-600">साहयोग</span></p>
                <p className="text-[10px] sm:text-[11px] text-navy-600 uppercase tracking-wider">
                  {lang === "hi" ? "झारखंड सरकार · नागरिक-विश्वविद्यालय-उद्योग सहयोग" : "Government of Jharkhand · Citizen–University–Industry Collaboration"}
                </p>
              </div>
            </Link>

            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-navy-700 hover:text-navy-900 hover:bg-navy-50 transition-colors"
                >
                  {lang === "hi" ? item.label.hi : item.label.en}
                </Link>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <LanguageToggle />
              <Link href="/notifications" className="hidden sm:flex p-2 rounded-full hover:bg-navy-50 text-navy-700">
                <Bell size={18} />
              </Link>
              <Link
                href="/login"
                className="hidden sm:flex items-center gap-1.5 rounded-full bg-navy-900 text-white text-sm font-medium px-4 py-2 hover:bg-navy-800 transition-colors"
              >
                <User size={15} />
                {lang === "hi" ? "लॉगिन" : "Login"}
              </Link>
              <button className="lg:hidden p-2 text-navy-800" onClick={() => setOpen((o) => !o)}>
                {open ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>
        <div className="tricolor-bar" />
      </div>

      {open && (
        <div className="lg:hidden glass border-b border-navy-100 px-4 py-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-navy-800 hover:bg-navy-50"
            >
              {lang === "hi" ? item.label.hi : item.label.en}
            </Link>
          ))}
          <Link href="/login" className="block px-3 py-2 rounded-lg text-sm font-semibold bg-navy-900 text-white text-center mt-2">
            {lang === "hi" ? "लॉगिन" : "Login"}
          </Link>
        </div>
      )}
    </header>
  );
}
